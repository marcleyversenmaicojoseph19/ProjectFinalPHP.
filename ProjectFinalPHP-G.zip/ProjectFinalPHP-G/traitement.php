<?php
       session_start();
       if(isset($_POST['match1']) and isset($_POST['score1']) and isset($_POST['score2']))
       {
              // match ---NOM EQUIPE
              $match1 = [$_POST['score1'], $_POST['score2']];
              $_SESSION['match1'] = $match1;

              $numero = $_POST['match1']; //recuperer numero match
              $nom= 'match'.$numero; //former un nom dynamiquement pour chaque match             
                     
                     $i = 0; 
                     $index = [];
                     $valeurs = [];
                     foreach ($_POST as $key => $value) {
                            $index[$i] = $key;
                            $valeurs[$i] = $value;
                            $i+=1;

                     }
                     $eq1 = $index[1];
                     $eq2 = $index[2];

                     $score1 = $valeurs[1];
                     $score2 = $valeurs[2];
                 //permet de comparer les deux equipes
                     for($i=0; $i<4; $i++){
                            if($_SESSION['gA'][$i][0] == $eq1){
                                   $indice1 = $i;
                                   echo($_SESSION['gA'][$indice1][0]);

                            }                            
                     }
                     //permet de comparer les deux equipes
                     for($i=0; $i<4; $i++){
                            if($_SESSION['gA'][$i][0] == $eq1){
                                   $indice1 = $i;
                                   echo($_SESSION['gA'][$indice1][0]);

                            }                            
                     }
                     //permet de comparer les deux equipes
                     for ($z=0; $z<4; $z++) { 
                            if($_SESSION['gA'][$z][0] == $eq2){
                                   $indice2 = $z;
                                   echo($_SESSION['gA'][$indice2][0]);
                            }
                     }
                     //condition de poursuite pour l'equipes 1 et 2 si le score1 est superieurs
                     if($score1>$score2){
                            $_SESSION['gA'][0][1] += 1;
                            $_SESSION['gA'][0][2] += 1;
                            $_SESSION['gA'][0][3] += 0;
                            $_SESSION['gA'][0][4] += 0;
                            $_SESSION['gA'][0][5] += $score1;
                            $_SESSION['gA'][0][6] += $score2;
                            $_SESSION['gA'][0][7] += $score1 - $score2;
                            $_SESSION['gA'][0][8] += 3;

                            $_SESSION['gA'][1][1] += 1;
                            $_SESSION['gA'][1][2] += 0;
                            $_SESSION['gA'][1][3] += 0;
                            $_SESSION['gA'][1][4] += 1;
                            $_SESSION['gA'][1][5] += $score2;
                            $_SESSION['gA'][1][6] += $score1;
                            $_SESSION['gA'][1][7] += $score2 - $score1;
                            $_SESSION['gA'][1][8] += 0;
                     } 
                     //condition de poursuite pour l'equipes 1 et 2 si le score2 est superieurs
                     else if($score1<$score2){
                     
                            $_SESSION['gA'][0][1] += 1;
                            $_SESSION['gA'][0][2] += 0;
                            $_SESSION['gA'][0][3] += 0;
                            $_SESSION['gA'][0][4] += 1;
                            $_SESSION['gA'][0][5] += $score1;
                            $_SESSION['gA'][0][6] += $score2;
                            $_SESSION['gA'][0][7] += $score1 - $score2;
                            $_SESSION['gA'][0][8] += 0;

                            $_SESSION['gA'][1][1] += 1;
                            $_SESSION['gA'][1][2] += 1;
                            $_SESSION['gA'][1][3] += 0;
                            $_SESSION['gA'][1][4] += 0;
                            $_SESSION['gA'][1][5] += $score2;
                            $_SESSION['gA'][1][6] += $score1;
                            $_SESSION['gA'][1][7] += $score2- $score1;
                            $_SESSION['gA'][1][8] += 3;
                     } 
                     //condition de poursuite pour l'equipes 1 et 2 si il y a match null
                     else {
                            $_SESSION['gA'][0][1] += 1;
                            $_SESSION['gA'][0][2] += 0;
                            $_SESSION['gA'][0][3] += 1;
                            $_SESSION['gA'][0][4] += 0;
                            $_SESSION['gA'][0][5] += $score1;
                            $_SESSION['gA'][0][6] += $score2;
                            $_SESSION['gA'][0][7] += 0;
                            $_SESSION['gA'][0][8] += 1;

                            $_SESSION['gA'][1][1] += 1;
                            $_SESSION['gA'][1][2] += 0;
                            $_SESSION['gA'][1][3] += 1;
                            $_SESSION['gA'][1][4] += 0;
                            $_SESSION['gA'][1][5] += $score2;
                            $_SESSION['gA'][1][6] += $score1;
                            $_SESSION['gA'][1][7] += 0;
                            $_SESSION['gA'][1][8] += 1;
                       }
                        header("Location: tirage.php");
       }
                //traitement pour le match2
              if(isset($_POST['match2']) and isset($_POST['score3']) and isset($_POST['score4']))
              {
                       $match2 = [$_POST['score3'], $_POST['score4']];
                       $_SESSION['match2'] = $match2;
         
                       $numero = $_POST['match2']; //recuperer numero match
                       $nom= 'match'.$numero; //former un nom dynamiquement pour chaque match 
                       
                       $i = 0; 
                       $index = [];
                       $valeurs = [];
                       foreach ($_POST as $key => $value) {
                              $index[$i] = $key;
                              $valeurs[$i] = $value;
                              $i+=1;
  
                       }
                       $eq1 = $index[1];
                       $eq2 = $index[2];
  
                       $score3 = $valeurs[1];
                       $score4 = $valeurs[2];
                   //permet de comparer les deux equipes
                       for($i=0; $i<4; $i++){
                              if($_SESSION['gA'][$i][0] == $eq1){
                                     $indice1 = $i;
                                     echo($_SESSION['gA'][$indice1][0]);
  
                              }                            
                       }
                       //permet de comparer les deux equipes
                       for($i=0; $i<4; $i++){
                              if($_SESSION['gA'][$i][0] == $eq1){
                                     $indice1 = $i;
                                     echo($_SESSION['gA'][$indice1][0]);
  
                              }                            
                       }
                       //permet de comparer les deux equipes
                       for ($z=0; $z<4; $z++) { 
                              if($_SESSION['gA'][$z][0] == $eq2){
                                     $indice2 = $z;
                                     echo($_SESSION['gA'][$indice2][0]);
                              }
                       }
                       //condition pour gerer les scores
                       if($score3>$score4){
                            $_SESSION['gA'][2][1] += 1;
                            $_SESSION['gA'][2][2] += 1;
                            $_SESSION['gA'][2][3] += 0;
                            $_SESSION['gA'][2][4] += 0;
                            $_SESSION['gA'][2][5] += $score3;
                            $_SESSION['gA'][2][6] += $score4;
                            $_SESSION['gA'][2][7] += $score3 - $score4;
                            $_SESSION['gA'][2][8] += 3;

                            $_SESSION['gA'][3][1] += 1;
                            $_SESSION['gA'][3][2] += 0;
                            $_SESSION['gA'][3][3] += 0;
                            $_SESSION['gA'][3][4] += 1;
                            $_SESSION['gA'][3][5] += $score4;
                            $_SESSION['gA'][3][6] += $score3;
                            $_SESSION['gA'][3][7] += $score4 - $score3;
                            $_SESSION['gA'][3][8] += 0;
                     } 
                      //condition de poursuite pour l'equipes 1 et 2 si le score4 est superieurs
                      else if($score3<$score4){
                     
                            $_SESSION['gA'][2][1] += 1;
                            $_SESSION['gA'][2][2] += 0;
                            $_SESSION['gA'][2][3] += 0;
                            $_SESSION['gA'][2][4] += 1;
                            $_SESSION['gA'][2][5] += $score3;
                            $_SESSION['gA'][2][6] += $score4;
                            $_SESSION['gA'][2][7] += $score3 - $score4;
                            $_SESSION['gA'][2][8] += 0;

                            $_SESSION['gA'][3][1] += 1;
                            $_SESSION['gA'][3][2] += 1;
                            $_SESSION['gA'][3][3] += 0;
                            $_SESSION['gA'][3][4] += 0;
                            $_SESSION['gA'][3][5] += $score4;
                            $_SESSION['gA'][3][6] += $score3;
                            $_SESSION['gA'][3][7] += $score4- $score3;
                            $_SESSION['gA'][3][8] += 3;
                     } 
                     //condition de poursuite pour l'equipes 1 et 2 si il y a match null
                     else {
                            $_SESSION['gA'][2][1] += 1;
                            $_SESSION['gA'][2][2] += 0;
                            $_SESSION['gA'][2][3] += 1;
                            $_SESSION['gA'][2][4] += 0;
                            $_SESSION['gA'][2][5] += $score3;
                            $_SESSION['gA'][2][6] += $score4;
                            $_SESSION['gA'][2][7] += 0;
                            $_SESSION['gA'][2][8] += 1;

                            $_SESSION['gA'][3][1] += 1;
                            $_SESSION['gA'][3][2] += 0;
                            $_SESSION['gA'][3][3] += 1;
                            $_SESSION['gA'][3][4] += 0;
                            $_SESSION['gA'][3][5] += $score4;
                            $_SESSION['gA'][3][6] += $score3;
                            $_SESSION['gA'][3][7] += 0;
                            $_SESSION['gA'][3][8] += 1;
                       }
                         header("Location: tirage.php");
              }   
              //traitement match3
               if(isset($_POST['match3']) and isset($_POST['score5']) and isset($_POST['score6']))
               {
                     $match3 = [$_POST['score5'], $_POST['score6']];
                     $_SESSION['match3'] = $match3;
       
                     $numero = $_POST['match3']; //recuperer numero match
                     $nom= 'match'.$numero; //former un nom dynamiquement pour chaque match 

                     $i = 0; 
                     $index = [];
                     $valeurs = [];
                     foreach ($_POST as $key => $value) {
                            $index[$i] = $key;
                            $valeurs[$i] = $value;
                            $i+=1;

                     }
                     $eq1 = $index[1];
                     $eq2 = $index[2];

                     $score5 = $valeurs[1];
                     $score6 = $valeurs[2];
                 //permet de comparer les deux equipes
                     for($i=0; $i<4; $i++){
                            if($_SESSION['gA'][$i][0] == $eq1){
                                   $indice1 = $i;
                                   echo($_SESSION['gA'][$indice1][0]);

                            }                            
                     }
                     //permet de comparer les deux equipes
                     for($i=0; $i<4; $i++){
                            if($_SESSION['gA'][$i][0] == $eq1){
                                   $indice1 = $i;
                                   echo($_SESSION['gA'][$indice1][0]);

                            }                            
                     }
                     //permet de comparer les deux equipes
                     for ($z=0; $z<4; $z++) { 
                            if($_SESSION['gA'][$z][0] == $eq2){
                                   $indice2 = $z;
                                   echo($_SESSION['gA'][$indice2][0]);
                            }
                     }

                     if( $_POST['score5']>$_POST['score6']){
                            $_SESSION['gA'][0][1] += 1;
                            $_SESSION['gA'][0][2] += 1;
                            $_SESSION['gA'][0][3] += 0;
                            $_SESSION['gA'][0][4] += 0;
                            $_SESSION['gA'][0][5] += $score5;
                            $_SESSION['gA'][0][6] += $score6;
                            $_SESSION['gA'][0][7] += $score5 - $score6;
                            $_SESSION['gA'][0][8] += 3;  
                            
                            $_SESSION['gA'][2][1] += 1;
                            $_SESSION['gA'][2][2] += 0;
                            $_SESSION['gA'][2][3] += 0;
                            $_SESSION['gA'][2][4] += 1;
                            $_SESSION['gA'][2][5] += $score6;
                            $_SESSION['gA'][2][6] += $score5;
                            $_SESSION['gA'][2][7] += $score6 - $score5;
                            $_SESSION['gA'][2][8] += 0;
                         }  
                     else if( $_POST['score5']<$_POST['score6']){
                            $_SESSION['gA'][0][1] += 1;
                            $_SESSION['gA'][0][2] += 0;
                            $_SESSION['gA'][0][3] += 0;
                            $_SESSION['gA'][0][4] += 1;
                            $_SESSION['gA'][0][5] += $score5;
                            $_SESSION['gA'][0][6] += $score6;
                            $_SESSION['gA'][0][7] += $score5 - $score6;
                            $_SESSION['gA'][0][8] += 0;

                            $_SESSION['gA'][2][1] += 1;
                            $_SESSION['gA'][2][2] += 1;
                            $_SESSION['gA'][2][3] += 0;
                            $_SESSION['gA'][2][4] += 0;
                            $_SESSION['gA'][2][5] += $score6;
                            $_SESSION['gA'][2][6] += $score5;
                            $_SESSION['gA'][2][7] += $score6 - $score5;
                            $_SESSION['gA'][2][8] += 3;
                         } 
              //condition de poursuite pour l'equipes 1 et 2 si il y a match null
                     else {
                            $_SESSION['gA'][0][1] += 1;
                            $_SESSION['gA'][0][2] += 0;
                            $_SESSION['gA'][0][3] += 1;
                            $_SESSION['gA'][0][4] += 0;
                            $_SESSION['gA'][0][5] += $score5;
                            $_SESSION['gA'][0][6] += $score6;
                            $_SESSION['gA'][0][7] += 0;
                            $_SESSION['gA'][0][8] += 1;

                            $_SESSION['gA'][2][1] += 1;
                            $_SESSION['gA'][2][2] += 0;
                            $_SESSION['gA'][2][3] += 1;
                            $_SESSION['gA'][2][4] += 0;
                            $_SESSION['gA'][2][5] += $score6;
                            $_SESSION['gA'][2][6] += $score5;
                            $_SESSION['gA'][2][7] += 0;
                            $_SESSION['gA'][2][8] += 1;
                          }
                          header("Location: tirage.php");
              }
              if(isset($_POST['match4']) and isset($_POST['score7']) and isset($_POST['score8']))
              {   $match4 = [$_POST['score7'], $_POST['score8']];
                     $_SESSION['match4'] = $match4;
       
                     $numero = $_POST['match4']; //recuperer numero match
                     $nom= 'match'.$numero; //former un nom dynamiquemescore8nt pour chaque match 
                    
                     $i = 0; 
                     $index = [];
                     $valeurs = [];
                     foreach ($_POST as $key => $value) {
                            $index[$i] = $key;
                            $valeurs[$i] = $value;
                            $i+=1;

                     }
                     $eq1 = $index[1];
                     $eq2 = $index[2];

                     $score7 = $valeurs[1];
                     $score8 = $valeurs[2];
                 //permet de comparer les deux equipes
                     for($i=0; $i<4; $i++){
                            if($_SESSION['gA'][$i][0] == $eq1){
                                   $indice1 = $i;
                                   echo($_SESSION['gA'][$indice1][0]);

                            }                            
                     }
                     //permet de comparer les deux equipes
                     for($i=0; $i<4; $i++){
                            if($_SESSION['gA'][$i][0] == $eq1){
                                   $indice1 = $i;
                                   echo($_SESSION['gA'][$indice1][0]);

                            }                            
                     }
                     //permet de comparer les deux equipes
                     for ($z=0; $z<4; $z++) { 
                            if($_SESSION['gA'][$z][0] == $eq2){
                                   $indice2 = $z;
                                   echo($_SESSION['gA'][$indice2][0]);
                            }
                     }

                 if( $_POST['score7']>$_POST['score8']){
                    $_SESSION['gA'][1][1] += 1;
                    $_SESSION['gA'][1][2] += 1;
                    $_SESSION['gA'][1][3] += 0;
                    $_SESSION['gA'][1][4] += 0;
                    $_SESSION['gA'][1][5] += $score7;
                    $_SESSION['gA'][1][6] += $score8;
                    $_SESSION['gA'][1][7] += $score7 - $score8;
                    $_SESSION['gA'][1][8] += 3;  
                    
                    $_SESSION['gA'][3][1] += 1;
                    $_SESSION['gA'][3][2] += 0;
                    $_SESSION['gA'][3][3] += 0;
                    $_SESSION['gA'][3][4] += 1;
                    $_SESSION['gA'][3][5] += $score8;
                    $_SESSION['gA'][3][6] += $score7;
                    $_SESSION['gA'][3][7] += $score8 - $score7;
                    $_SESSION['gA'][3][8] += 0;
              }       
              //condition pour si le score8 est superieur au score7

              else if( $_POST['score7']<$_POST['score8']){
                     $_SESSION['gA'][1][1] += 1;
                     $_SESSION['gA'][1][2] += 0;
                     $_SESSION['gA'][1][3] += 0;
                     $_SESSION['gA'][1][4] += 1;
                     $_SESSION['gA'][1][5] += $score7;
                     $_SESSION['gA'][1][6] += $score8;
                     $_SESSION['gA'][1][7] += $score7 - $score8;
                     $_SESSION['gA'][1][8] += 0;

                     $_SESSION['gA'][3][1] += 1;
                     $_SESSION['gA'][3][2] += 1;
                     $_SESSION['gA'][3][3] += 0;
                     $_SESSION['gA'][3][4] += 0;
                     $_SESSION['gA'][3][5] += $score8;
                     $_SESSION['gA'][3][6] += $score7;
                     $_SESSION['gA'][3][7] += $score8 - $score7;
                     $_SESSION['gA'][3][8] += 3;
                  } 
       //condition de poursuite pour l'equipes 1 et 2 si il y a match null
              else {
                     $_SESSION['gA'][1][1] += 1;
                     $_SESSION['gA'][1][2] += 0;
                     $_SESSION['gA'][1][3] += 1;
                     $_SESSION['gA'][1][4] += 0;
                     $_SESSION['gA'][1][5] += $score7;
                     $_SESSION['gA'][1][6] += $score8;
                     $_SESSION['gA'][1][7] += 0;
                     $_SESSION['gA'][1][8] += 1;

                     $_SESSION['gA'][3][1] += 1;
                     $_SESSION['gA'][3][2] += 0;
                     $_SESSION['gA'][3][3] += 1;
                     $_SESSION['gA'][3][4] += 0;
                     $_SESSION['gA'][3][5] += $score8;
                     $_SESSION['gA'][3][6] += $score7;
                     $_SESSION['gA'][3][7] += 0;
                     $_SESSION['gA'][3][8] += 1;
                   }
                   header("Location: tirage.php");
             }
                //traitement match5
                if(isset($_POST['match5']) and isset($_POST['score9']) and isset($_POST['score10']))
                {
                     $match5 = [$_POST['score9'], $_POST['score10']];
                     $_SESSION['match5'] = $match5;
       
                     $numero = $_POST['match5']; //recuperer numero match
                     $nom= 'match'.$numero; //former un nom dynamiquemescore8nt pour chaque match

                     $i = 0; 
                     $index = [];
                     $valeurs = [];
                     foreach ($_POST as $key => $value) {
                            $index[$i] = $key;
                            $valeurs[$i] = $value;
                            $i+=1;

                     }
                     $eq1 = $index[1];
                     $eq2 = $index[2];

                     $score9 = $valeurs[1];
                     $score10 = $valeurs[2];
                 //permet de comparer les deux equipes
                     for($i=0; $i<4; $i++){
                            if($_SESSION['gA'][$i][0] == $eq1){
                                   $indice1 = $i;
                                   echo($_SESSION['gA'][$indice1][0]);

                            }                            
                     }
                     //permet de comparer les deux equipes
                     for($i=0; $i<4; $i++){
                            if($_SESSION['gA'][$i][0] == $eq1){
                                   $indice1 = $i;
                                   echo($_SESSION['gA'][$indice1][0]);

                            }                            
                     }
                     //permet de comparer les deux equipes
                     for ($z=0; $z<4; $z++) { 
                            if($_SESSION['gA'][$z][0] == $eq2){
                                   $indice2 = $z;
                                   echo($_SESSION['gA'][$indice2][0]);
                            }
                     }

                   if( $_POST['score9']>$_POST['score10']){
                      $_SESSION['gA'][0][1] += 1;
                      $_SESSION['gA'][0][2] += 1;
                      $_SESSION['gA'][0][3] += 0;
                      $_SESSION['gA'][0][4] += 0;
                      $_SESSION['gA'][0][5] += $score9;
                      $_SESSION['gA'][0][6] += $score10;
                      $_SESSION['gA'][0][7] += $score9 - $score10;
                      $_SESSION['gA'][0][8] += 3;  
                      
                      $_SESSION['gA'][3][1] += 1;
                      $_SESSION['gA'][3][2] += 0;
                      $_SESSION['gA'][3][3] += 0;
                      $_SESSION['gA'][3][4] += 1;
                      $_SESSION['gA'][3][5] += $score10;
                      $_SESSION['gA'][3][6] += $score9;
                      $_SESSION['gA'][3][7] += $score10 - $score9;
                      $_SESSION['gA'][3][8] += 0;
                }  
                  //score10 superieur a score9
                  else if( $_POST['score9']<$_POST['score10']){
                     $_SESSION['gA'][0][1] += 1;
                     $_SESSION['gA'][0][2] += 0;
                     $_SESSION['gA'][0][3] += 0;
                     $_SESSION['gA'][0][4] += 1;
                     $_SESSION['gA'][0][5] += $score9;
                     $_SESSION['gA'][0][6] += $score10;
                     $_SESSION['gA'][0][7] += $score9 - $score10;
                     $_SESSION['gA'][0][8] += 0;

                     $_SESSION['gA'][3][1] += 1;
                     $_SESSION['gA'][3][2] += 1;
                     $_SESSION['gA'][3][3] += 0;
                     $_SESSION['gA'][3][4] += 0;
                     $_SESSION['gA'][3][5] += $score10;
                     $_SESSION['gA'][3][6] += $score9;
                     $_SESSION['gA'][3][7] += $score10 - $score9;
                     $_SESSION['gA'][3][8] += 3;
                  } 
       //condition de poursuite pour l'equipes 1 et 2 si il y a match null
              else {
                     $_SESSION['gA'][0][1] += 1;
                     $_SESSION['gA'][0][2] += 0;
                     $_SESSION['gA'][0][3] += 1;
                     $_SESSION['gA'][0][4] += 0;
                     $_SESSION['gA'][0][5] += $score9;
                     $_SESSION['gA'][0][6] += $score10;
                     $_SESSION['gA'][0][7] += 0;
                     $_SESSION['gA'][0][8] += 1;

                     $_SESSION['gA'][3][1] += 1;
                     $_SESSION['gA'][3][2] += 0;
                     $_SESSION['gA'][3][3] += 1;
                     $_SESSION['gA'][3][4] += 0;
                     $_SESSION['gA'][3][5] += $score10;
                     $_SESSION['gA'][3][6] += $score9;
                     $_SESSION['gA'][3][7] += 0;
                     $_SESSION['gA'][3][8] += 1;
                   }     
                   header("Location: tirage.php");
               }
                 //traitement match6
                 if(isset($_POST['match6']) and isset($_POST['score11']) and isset($_POST['score12']))
                 {
                     $match6 = [$_POST['score11'], $_POST['score12']];
                     $_SESSION['match6'] = $match6;
       
                     $numero = $_POST['match6']; //recuperer numero match
                     $nom= 'match'.$numero; //former un nom dynamiquement pour chaque match

                     $i = 0; 
                     $index = [];
                     $valeurs = [];
                     foreach ($_POST as $key => $value) {
                            $index[$i] = $key;
                            $valeurs[$i] = $value;
                            $i+=1;

                     }
                     $eq1 = $index[1];
                     $eq2 = $index[2];

                     $score11 = $valeurs[1];
                     $score12 = $valeurs[2];
                 //permet de comparer les deux equipes
                     for($i=0; $i<4; $i++){
                            if($_SESSION['gA'][$i][0] == $eq1){
                                   $indice1 = $i;
                                   echo($_SESSION['gA'][$indice1][0]);

                            }                            
                     }
                     //permet de comparer les deux equipes
                     for($i=0; $i<4; $i++){
                            if($_SESSION['gA'][$i][0] == $eq1){
                                   $indice1 = $i;
                                   echo($_SESSION['gA'][$indice1][0]);

                            }                            
                     }
                     //permet de comparer les deux equipes
                     for ($z=0; $z<4; $z++) { 
                            if($_SESSION['gA'][$z][0] == $eq2){
                                   $indice2 = $z;
                                   echo($_SESSION['gA'][$indice2][0]);
                            }
                     }

                    if( $_POST['score11']>$_POST['score12']){
                       $_SESSION['gA'][1][1] += 1;
                       $_SESSION['gA'][1][2] += 1;
                       $_SESSION['gA'][1][3] += 0;
                       $_SESSION['gA'][1][4] += 0;
                       $_SESSION['gA'][1][5] += $score11;
                       $_SESSION['gA'][1][6] += $score12;
                       $_SESSION['gA'][1][7] += $score11 - $score12;
                       $_SESSION['gA'][1][8] += 3;  
                       
                       $_SESSION['gA'][2][1] += 1;
                       $_SESSION['gA'][2][2] += 0;
                       $_SESSION['gA'][2][3] += 0;
                       $_SESSION['gA'][2][4] += 1;
                       $_SESSION['gA'][2][5] += $score12;
                       $_SESSION['gA'][2][6] += $score11;
                       $_SESSION['gA'][2][7] += $score12 - $score11;
                       $_SESSION['gA'][2][8] += 0;
                 }      
                  //score12 superieur a score11
                     else if( $_POST['score11']<$_POST['score12']){
                            $_SESSION['gA'][1][1] += 1;
                            $_SESSION['gA'][1][2] += 0;
                            $_SESSION['gA'][1][3] += 0;
                            $_SESSION['gA'][1][4] += 1;
                            $_SESSION['gA'][1][5] += $score11;
                            $_SESSION['gA'][1][6] += $score12;
                            $_SESSION['gA'][1][7] += $score11 - $score12;
                            $_SESSION['gA'][1][8] += 0;

                            $_SESSION['gA'][2][1] += 1;
                            $_SESSION['gA'][2][2] += 1;
                            $_SESSION['gA'][2][3] += 0;
                            $_SESSION['gA'][2][4] += 0;
                            $_SESSION['gA'][2][5] += $score12;
                            $_SESSION['gA'][2][6] += $score11;
                            $_SESSION['gA'][2][7] += $score12 - $score11;
                            $_SESSION['gA'][2][8] += 3;
                     } 
              //condition de poursuite pour l'equipes 1 et 2 si il y a match null
                     else {
                            $_SESSION['gA'][1][1] += 1;
                            $_SESSION['gA'][1][2] += 0;
                            $_SESSION['gA'][1][3] += 1;
                            $_SESSION['gA'][1][4] += 0;
                            $_SESSION['gA'][1][5] += $score11;
                            $_SESSION['gA'][1][6] += $score12;
                            $_SESSION['gA'][1][7] += 0;
                            $_SESSION['gA'][1][8] += 1;

                            $_SESSION['gA'][2][1] += 1;
                            $_SESSION['gA'][2][2] += 0;
                            $_SESSION['gA'][2][3] += 1;
                            $_SESSION['gA'][2][4] += 0;
                            $_SESSION['gA'][2][5] += $score12;
                            $_SESSION['gA'][2][6] += $score11;
                            $_SESSION['gA'][2][7] += 0;
                            $_SESSION['gA'][2][8] += 1;
                     }
                     header("Location: tirage.php");      
                }
              
              
              //traitement match7

               if(isset($_POST['match7']) and isset($_POST['score13']) and isset($_POST['score14']))
               {
                        $match7 = [$_POST['score13'], $_POST['score14']];
                        $_SESSION['match7'] = $match7;
          
                        $numero = $_POST['match7']; //recuperer numero match
                        $nom= 'match'.$numero; //former un nom dynamiquement pour chaque match 
                        
                        $i = 0; 
                        $index = [];
                        $valeurs = [];
                        foreach ($_POST as $key => $value) {
                               $index[$i] = $key;
                               $valeurs[$i] = $value;
                               $i+=1;
   
                        }
                        $eq1 = $index[1];
                        $eq2 = $index[2];
   
                        $score13 = $valeurs[1];
                        $score14 = $valeurs[2];
                    //permet de comparer les deux equipes
                        for($i=0; $i<4; $i++){
                               if($_SESSION['gB'][$i][0] == $eq1){
                                      $indice1 = $i;
                                      echo($_SESSION['gB'][$indice1][0]);
   
                               }                            
                        }
                        //permet de comparer les deux equipes
                        for($i=0; $i<4; $i++){
                               if($_SESSION['gB'][$i][0] == $eq1){
                                      $indice1 = $i;
                                      echo($_SESSION['gB'][$indice1][0]);
   
                               }                            
                        }
                        //permet de comparer les deux equipes
                        for ($z=0; $z<4; $z++) { 
                               if($_SESSION['gB'][$z][0] == $eq2){
                                      $indice2 = $z;
                                      echo($_SESSION['gB'][$indice2][0]);
                               }
                        }
                         //condition pour gerer les scores
                         if($score13>$score14){
                             $_SESSION['gB'][0][1] += 1;
                             $_SESSION['gB'][0][2] += 1;
                             $_SESSION['gB'][0][3] += 0;
                             $_SESSION['gB'][0][4] += 0;
                             $_SESSION['gB'][0][5] += $score13;
                             $_SESSION['gB'][0][6] += $score14;
                             $_SESSION['gB'][0][7] += $score13 - $score14;
                             $_SESSION['gB'][0][8] += 3;
 
                             $_SESSION['gB'][1][1] += 1;
                             $_SESSION['gB'][1][2] += 0;
                             $_SESSION['gB'][1][3] += 0;
                             $_SESSION['gB'][1][4] += 1;
                             $_SESSION['gB'][1][5] += $score14;
                             $_SESSION['gB'][1][6] += $score13;
                             $_SESSION['gB'][1][7] += $score14 - $score13;
                             $_SESSION['gB'][1][8] += 0;
                      }
                       //condition de poursuite pour l'equipes 1 et 2 si le score14 est superieurs
                       else if($score13<$score14){
                     
                            $_SESSION['gB'][0][1] += 1;
                            $_SESSION['gB'][0][2] += 0;
                            $_SESSION['gB'][0][3] += 0;
                            $_SESSION['gB'][0][4] += 1;
                            $_SESSION['gB'][0][5] += $score13;
                            $_SESSION['gB'][0][6] += $score14;
                            $_SESSION['gB'][0][7] += $score13 - $score14;
                            $_SESSION['gB'][0][8] += 0;

                            $_SESSION['gB'][1][1] += 1;
                            $_SESSION['gB'][1][2] += 1;
                            $_SESSION['gB'][1][3] += 0;
                            $_SESSION['gB'][1][4] += 0;
                            $_SESSION['gB'][1][5] += $score14;
                            $_SESSION['gB'][1][6] += $score13;
                            $_SESSION['gB'][1][7] += $score14 - $score13;
                            $_SESSION['gB'][1][8] += 3;
                     }  
                     //condition de poursuite pour l'equipes 1 et 2 si il y a match null
                     else {
                            $_SESSION['gB'][0][1] += 1;
                            $_SESSION['gB'][0][2] += 0;
                            $_SESSION['gB'][0][3] += 1;
                            $_SESSION['gB'][0][4] += 0;
                            $_SESSION['gB'][0][5] += $score13;
                            $_SESSION['gB'][0][6] += $score14;
                            $_SESSION['gB'][0][7] += 0;
                            $_SESSION['gB'][0][8] += 1;

                            $_SESSION['gB'][1][1] += 1;
                            $_SESSION['gB'][1][2] += 0;
                            $_SESSION['gB'][1][3] += 1;
                            $_SESSION['gB'][1][4] += 0;
                            $_SESSION['gB'][1][5] += $score14;
                            $_SESSION['gB'][1][6] += $score13;
                            $_SESSION['gB'][1][7] += 0;
                            $_SESSION['gB'][1][8] += 1;
                       }
                       header("Location: tirage.php");
               }

               //traitement match8

               if(isset($_POST['match8']) and isset($_POST['score15']) and isset($_POST['score16']))
               {
                        $match8 = [$_POST['score15'], $_POST['score16']];
                        $_SESSION['match8'] = $match8;
          
                        $numero = $_POST['match8']; //recuperer numero match
                        $nom= 'match'.$numero; //former un nom dynamiquement pour chaque match 
                        
                        $i = 0; 
                        $index = [];
                        $valeurs = [];
                        foreach ($_POST as $key => $value) {
                               $index[$i] = $key;
                               $valeurs[$i] = $value;
                               $i+=1;
   
                        }
                        $eq1 = $index[1];
                        $eq2 = $index[2];
   
                        $score15 = $valeurs[1];
                        $score16 = $valeurs[2];
                    //permet de comparer les deux equipes
                        for($i=0; $i<4; $i++){
                               if($_SESSION['gB'][$i][0] == $eq1){
                                      $indice1 = $i;
                                      echo($_SESSION['gB'][$indice1][0]);
   
                               }                            
                        }
                        //permet de comparer les deux equipes
                        for($i=0; $i<4; $i++){
                               if($_SESSION['gB'][$i][0] == $eq1){
                                      $indice1 = $i;
                                      echo($_SESSION['gB'][$indice1][0]);
   
                               }                            
                        }
                        //permet de comparer les deux equipes
                        for ($z=0; $z<4; $z++) { 
                               if($_SESSION['gB'][$z][0] == $eq2){
                                      $indice2 = $z;
                                      echo($_SESSION['gB'][$indice2][0]);
                               }
                        }
                         //condition pour gerer les scores
                         if($score15>$score16){
                             $_SESSION['gB'][2][1] += 1;
                             $_SESSION['gB'][2][2] += 1;
                             $_SESSION['gB'][2][3] += 0;
                             $_SESSION['gB'][2][4] += 0;
                             $_SESSION['gB'][2][5] += $score15;
                             $_SESSION['gB'][2][6] += $score16;
                             $_SESSION['gB'][2][7] += $score15 - $score16;
                             $_SESSION['gB'][2][8] += 3;
 
                             $_SESSION['gB'][3][1] += 1;
                             $_SESSION['gB'][3][2] += 0;
                             $_SESSION['gB'][3][3] += 0;
                             $_SESSION['gB'][3][4] += 1;
                             $_SESSION['gB'][3][5] += $score16;
                             $_SESSION['gB'][3][6] += $score15;
                             $_SESSION['gB'][3][7] += $score16 - $score15;
                             $_SESSION['gB'][3][8] += 0;
                      }
                       //condition de poursuite pour l'equipes 1 et 2 si le score16 est superieurs
                       else if($score15<$score16){
                     
                            $_SESSION['gB'][2][1] += 1;
                            $_SESSION['gB'][2][2] += 0;
                            $_SESSION['gB'][2][3] += 0;
                            $_SESSION['gB'][2][4] += 1;
                            $_SESSION['gB'][2][5] += $score15;
                            $_SESSION['gB'][2][6] += $score16;
                            $_SESSION['gB'][2][7] += $score15 - $score16;
                            $_SESSION['gB'][2][8] += 0;

                            $_SESSION['gB'][3][1] += 1;
                            $_SESSION['gB'][3][2] += 1;
                            $_SESSION['gB'][3][3] += 0;
                            $_SESSION['gB'][3][4] += 0;
                            $_SESSION['gB'][3][5] += $score16;
                            $_SESSION['gB'][3][6] += $score15;
                            $_SESSION['gB'][3][7] += $score16 - $score15;
                            $_SESSION['gB'][3][8] += 3;
                     }  
                     //condition de poursuite pour l'equipes 1 et 2 si il y a match null
                     else {
                            $_SESSION['gB'][2][1] += 1;
                            $_SESSION['gB'][2][2] += 0;
                            $_SESSION['gB'][2][3] += 1;
                            $_SESSION['gB'][2][4] += 0;
                            $_SESSION['gB'][2][5] += $score15;
                            $_SESSION['gB'][2][6] += $score16;
                            $_SESSION['gB'][2][7] += 0;
                            $_SESSION['gB'][2][8] += 1;

                            $_SESSION['gB'][3][1] += 1;
                            $_SESSION['gB'][3][2] += 0;
                            $_SESSION['gB'][3][3] += 1;
                            $_SESSION['gB'][3][4] += 0;
                            $_SESSION['gB'][3][5] += $score16;
                            $_SESSION['gB'][3][6] += $score15;
                            $_SESSION['gB'][3][7] += 0;
                            $_SESSION['gB'][3][8] += 1;
                       }
                       header("Location: tirage.php");
               }

               //traitement match9
               if(isset($_POST['match9']) and isset($_POST['score17']) and isset($_POST['score18']))
               {
                   $match9 = [$_POST['score17'], $_POST['score18']];
                   $_SESSION['match9'] = $match9;
     
                   $numero = $_POST['match9']; //recuperer numero match
                   $nom= 'match'.$numero; //former un nom dynamiquemescore8nt pour chaque match

                   $i = 0; 
                   $index = [];
                   $valeurs = [];
                   foreach ($_POST as $key => $value) {
                          $index[$i] = $key;
                          $valeurs[$i] = $value;
                          $i+=1;

                   }
                   $eq1 = $index[1];
                   $eq2 = $index[2];

                   $score17 = $valeurs[1];
                   $score18 = $valeurs[2];
               //permet de comparer les deux equipes
                   for($i=0; $i<4; $i++){
                          if($_SESSION['gB'][$i][0] == $eq1){
                                 $indice1 = $i;
                                 echo($_SESSION['gB'][$indice1][0]);

                          }                            
                   }
                   //permet de comparer les deux equipes
                   for($i=0; $i<4; $i++){
                          if($_SESSION['gB'][$i][0] == $eq1){
                                 $indice1 = $i;
                                 echo($_SESSION['gB'][$indice1][0]);

                          }                            
                   }
                   //permet de comparer les deux equipes
                   for ($z=0; $z<4; $z++) { 
                          if($_SESSION['gB'][$z][0] == $eq2){
                                 $indice2 = $z;
                                 echo($_SESSION['gB'][$indice2][0]);
                          }
                   }

                  if( $_POST['score17']>$_POST['score18']){
                            $_SESSION['gB'][0][1] += 1;
                            $_SESSION['gB'][0][2] += 1;
                            $_SESSION['gB'][0][3] += 0;
                            $_SESSION['gB'][0][4] += 0;
                            $_SESSION['gB'][0][5] += $score17;
                            $_SESSION['gB'][0][6] += $score18;
                            $_SESSION['gB'][0][7] += $score17 - $score18;
                            $_SESSION['gB'][0][8] += 3;  
                            
                            $_SESSION['gB'][2][1] += 1;
                            $_SESSION['gB'][2][2] += 0;
                            $_SESSION['gB'][2][3] += 0;
                            $_SESSION['gB'][2][4] += 1;
                            $_SESSION['gB'][2][5] += $score18;
                            $_SESSION['gB'][2][6] += $score17;
                            $_SESSION['gB'][2][7] += $score18 - $score17;
                            $_SESSION['gB'][2][8] += 0;
               }      
                //score18 superieur a score17
                   else if( $_POST['score17']<$_POST['score18']){
                          $_SESSION['gB'][0][1] += 1;
                          $_SESSION['gB'][0][2] += 0;
                          $_SESSION['gB'][0][3] += 0;
                          $_SESSION['gB'][0][4] += 1;
                          $_SESSION['gB'][0][5] += $score17;
                          $_SESSION['gB'][0][6] += $score18;
                          $_SESSION['gB'][0][7] += $score17 - $score18;
                          $_SESSION['gB'][0][8] += 0;

                          $_SESSION['gB'][2][1] += 1;
                          $_SESSION['gB'][2][2] += 1;
                          $_SESSION['gB'][2][3] += 0;
                          $_SESSION['gB'][2][4] += 0;
                          $_SESSION['gB'][2][5] += $score18;
                          $_SESSION['gB'][2][6] += $score17;
                          $_SESSION['gB'][2][7] += $score18 - $score17;
                          $_SESSION['gB'][2][8] += 3;
                   } 
            //condition de poursuite pour l'equipes 1 et 2 si il y a match null
                   else {
                          $_SESSION['gB'][0][1] += 1;
                          $_SESSION['gB'][0][2] += 0;
                          $_SESSION['gB'][0][3] += 1;
                          $_SESSION['gB'][0][4] += 0;
                          $_SESSION['gB'][0][5] += $score17;
                          $_SESSION['gB'][0][6] += $score18;
                          $_SESSION['gB'][0][7] += 0;
                          $_SESSION['gB'][0][8] += 1;

                          $_SESSION['gB'][2][1] += 1;
                          $_SESSION['gB'][2][2] += 0;
                          $_SESSION['gB'][2][3] += 1;
                          $_SESSION['gB'][2][4] += 0;
                          $_SESSION['gB'][2][5] += $score18;
                          $_SESSION['gB'][2][6] += $score17;
                          $_SESSION['gB'][2][7] += 0;
                          $_SESSION['gB'][2][8] += 1;
                   }      
                   header("Location: tirage.php");
              }

               //traitement match10
               if(isset($_POST['match10']) and isset($_POST['score19']) and isset($_POST['score20']))
               {
                   $match10 = [$_POST['score19'], $_POST['score20']];
                   $_SESSION['match10'] = $match10;
     
                   $numero = $_POST['match10']; //recuperer numero match
                   $nom= 'match'.$numero; //former un nom dynamiquement pour chaque match

                   $i = 0; 
                   $index = [];
                   $valeurs = [];
                   foreach ($_POST as $key => $value) {
                          $index[$i] = $key;
                          $valeurs[$i] = $value;
                          $i+=1;

                   }
                   $eq1 = $index[1];
                   $eq2 = $index[2];

                   $score19 = $valeurs[1];
                   $score20 = $valeurs[2];
               //permet de comparer les deux equipes
                   for($i=0; $i<4; $i++){
                          if($_SESSION['gB'][$i][0] == $eq1){
                                 $indice1 = $i;
                                 echo($_SESSION['gB'][$indice1][0]);

                          }                            
                   }
                   //permet de comparer les deux equipes
                   for($i=0; $i<4; $i++){
                          if($_SESSION['gB'][$i][0] == $eq1){
                                 $indice1 = $i;
                                 echo($_SESSION['gB'][$indice1][0]);

                          }                            
                   }
                   //permet de comparer les deux equipes
                   for ($z=0; $z<4; $z++) { 
                          if($_SESSION['gB'][$z][0] == $eq2){
                                 $indice2 = $z;
                                 echo($_SESSION['gB'][$indice2][0]);
                          }
                   }

                  if( $_POST['score19']>$_POST['score20']){
                            $_SESSION['gB'][1][1] += 1;
                            $_SESSION['gB'][1][2] += 1;
                            $_SESSION['gB'][1][3] += 0;
                            $_SESSION['gB'][1][4] += 0;
                            $_SESSION['gB'][1][5] += $score19;
                            $_SESSION['gB'][1][6] += $score20;
                            $_SESSION['gB'][1][7] += $score19 - $score20;
                            $_SESSION['gB'][1][8] += 3;  
                            
                            $_SESSION['gB'][3][1] += 1;
                            $_SESSION['gB'][3][2] += 0;
                            $_SESSION['gB'][3][3] += 0;
                            $_SESSION['gB'][3][4] += 1;
                            $_SESSION['gB'][3][5] += $score20;
                            $_SESSION['gB'][3][6] += $score19;
                            $_SESSION['gB'][3][7] += $score20 - $score19;
                            $_SESSION['gB'][3][8] += 0;
               }      
                //score20 superieur a score19
                   else if( $_POST['score19']<$_POST['score20']){
                          $_SESSION['gB'][1][1] += 1;
                          $_SESSION['gB'][1][2] += 0;
                          $_SESSION['gB'][1][3] += 0;
                          $_SESSION['gB'][1][4] += 1;
                          $_SESSION['gB'][1][5] += $score19;
                          $_SESSION['gB'][1][6] += $score20;
                          $_SESSION['gB'][1][7] += $score19 - $score20;
                          $_SESSION['gB'][1][8] += 0;

                          $_SESSION['gB'][3][1] += 1;
                          $_SESSION['gB'][3][2] += 1;
                          $_SESSION['gB'][3][3] += 0;
                          $_SESSION['gB'][3][4] += 0;
                          $_SESSION['gB'][3][5] += $score20;
                          $_SESSION['gB'][3][6] += $score19;
                          $_SESSION['gB'][3][7] += $score20 - $score19;
                          $_SESSION['gB'][3][8] += 3;
                   } 
            //condition de poursuite pour l'equipes 1 et 2 si il y a match null
                   else {
                          $_SESSION['gB'][1][1] += 1;
                          $_SESSION['gB'][1][2] += 0;
                          $_SESSION['gB'][1][3] += 1;
                          $_SESSION['gB'][1][4] += 0;
                          $_SESSION['gB'][1][5] += $score19;
                          $_SESSION['gB'][1][6] += $score20;
                          $_SESSION['gB'][1][7] += 0;
                          $_SESSION['gB'][1][8] += 1;

                          $_SESSION['gB'][3][1] += 1;
                          $_SESSION['gB'][3][2] += 0;
                          $_SESSION['gB'][3][3] += 1;
                          $_SESSION['gB'][3][4] += 0;
                          $_SESSION['gB'][3][5] += $score20;
                          $_SESSION['gB'][3][6] += $score19;
                          $_SESSION['gB'][3][7] += 0;
                          $_SESSION['gB'][3][8] += 1;
                   }     
                   header("Location: tirage.php"); 
              }

              //traitement match11
              if(isset($_POST['match11']) and isset($_POST['score21']) and isset($_POST['score22']))
              {
                  $match11 = [$_POST['score21'], $_POST['score22']];
                  $_SESSION['match11'] = $match11;
    
                  $numero = $_POST['match11']; //recuperer numero match
                  $nom= 'match'.$numero; //former un nom dynamiquement pour chaque match

                  $i = 0; 
                  $index = [];
                  $valeurs = [];
                  foreach ($_POST as $key => $value) {
                         $index[$i] = $key;
                         $valeurs[$i] = $value;
                         $i+=1;

                  }
                  $eq1 = $index[1];
                  $eq2 = $index[2];

                  $score21 = $valeurs[1];
                  $score22 = $valeurs[2];
              //permet de comparer les deux equipes
                  for($i=0; $i<4; $i++){
                         if($_SESSION['gB'][$i][0] == $eq1){
                                $indice1 = $i;
                                echo($_SESSION['gB'][$indice1][0]);

                         }                            
                  }
                  //permet de comparer les deux equipes
                  for($i=0; $i<4; $i++){
                         if($_SESSION['gB'][$i][0] == $eq1){
                                $indice1 = $i;
                                echo($_SESSION['gB'][$indice1][0]);

                         }                            
                  }
                  //permet de comparer les deux equipes
                  for ($z=0; $z<4; $z++) { 
                         if($_SESSION['gB'][$z][0] == $eq2){
                                $indice2 = $z;
                                echo($_SESSION['gB'][$indice2][0]);
                         }
                  }

                 if( $_POST['score21']>$_POST['score22']){
                           $_SESSION['gB'][0][1] += 1;
                           $_SESSION['gB'][0][2] += 1;
                           $_SESSION['gB'][0][3] += 0;
                           $_SESSION['gB'][0][4] += 0;
                           $_SESSION['gB'][0][5] += $score21;
                           $_SESSION['gB'][0][6] += $score22;
                           $_SESSION['gB'][0][7] += $score21 - $score22;
                           $_SESSION['gB'][0][8] += 3;  
                           
                           $_SESSION['gB'][3][1] += 1;
                           $_SESSION['gB'][3][2] += 0;
                           $_SESSION['gB'][3][3] += 0;
                           $_SESSION['gB'][3][4] += 1;
                           $_SESSION['gB'][3][5] += $score22;
                           $_SESSION['gB'][3][6] += $score21;
                           $_SESSION['gB'][3][7] += $score22 - $score21;
                           $_SESSION['gB'][3][8] += 0;
              }      
               //score22 superieur a score21
                  else if( $_POST['score21']<$_POST['score22']){
                         $_SESSION['gB'][0][1] += 1;
                         $_SESSION['gB'][0][2] += 0;
                         $_SESSION['gB'][0][3] += 0;
                         $_SESSION['gB'][0][4] += 1;
                         $_SESSION['gB'][0][5] += $score21;
                         $_SESSION['gB'][0][6] += $score22;
                         $_SESSION['gB'][0][7] += $score21 - $score22;
                         $_SESSION['gB'][0][8] += 0;

                         $_SESSION['gB'][3][1] += 1;
                         $_SESSION['gB'][3][2] += 1;
                         $_SESSION['gB'][3][3] += 0;
                         $_SESSION['gB'][3][4] += 0;
                         $_SESSION['gB'][3][5] += $score22;
                         $_SESSION['gB'][3][6] += $score21;
                         $_SESSION['gB'][3][7] += $score22 - $score21;
                         $_SESSION['gB'][3][8] += 3;
                  } 
           //condition de poursuite pour l'equipes 1 et 2 si il y a match null
                  else {
                         $_SESSION['gB'][0][1] += 1;
                         $_SESSION['gB'][0][2] += 0;
                         $_SESSION['gB'][0][3] += 1;
                         $_SESSION['gB'][0][4] += 0;
                         $_SESSION['gB'][0][5] += $score21;
                         $_SESSION['gB'][0][6] += $score22;
                         $_SESSION['gB'][0][7] += 0;
                         $_SESSION['gB'][0][8] += 1;

                         $_SESSION['gB'][3][1] += 1;
                         $_SESSION['gB'][3][2] += 0;
                         $_SESSION['gB'][3][3] += 1;
                         $_SESSION['gB'][3][4] += 0;
                         $_SESSION['gB'][3][5] += $score22;
                         $_SESSION['gB'][3][6] += $score21;
                         $_SESSION['gB'][3][7] += 0;
                         $_SESSION['gB'][3][8] += 1;
                  }      
                  header("Location: tirage.php");
             }
              //traitement match12
              if(isset($_POST['match12']) and isset($_POST['score23']) and isset($_POST['score24']))
              {
                  $match12 = [$_POST['score23'], $_POST['score24']];
                  $_SESSION['match12'] = $match12;
    
                  $numero = $_POST['match12']; //recuperer numero match
                  $nom= 'match'.$numero; //former un nom dynamiquement pour chaque match

                  $i = 0; 
                  $index = [];
                  $valeurs = [];
                  foreach ($_POST as $key => $value) {
                         $index[$i] = $key;
                         $valeurs[$i] = $value;
                         $i+=1;

                  }
                  $eq1 = $index[1];
                  $eq2 = $index[2];

                  $score23 = $valeurs[1];
                  $score24 = $valeurs[2];
              //permet de comparer les deux equipes
                  for($i=0; $i<4; $i++){
                         if($_SESSION['gB'][$i][0] == $eq1){
                                $indice1 = $i;
                                echo($_SESSION['gB'][$indice1][0]);

                         }                            
                  }
                  //permet de comparer les deux equipes
                  for($i=0; $i<4; $i++){
                         if($_SESSION['gB'][$i][0] == $eq1){
                                $indice1 = $i;
                                echo($_SESSION['gB'][$indice1][0]);

                         }                            
                  }
                  //permet de comparer les deux equipes
                  for ($z=0; $z<4; $z++) { 
                         if($_SESSION['gB'][$z][0] == $eq2){
                                $indice2 = $z;
                                echo($_SESSION['gB'][$indice2][0]);
                         }
                  }

                 if( $_POST['score23']>$_POST['score24']){
                           $_SESSION['gB'][1][1] += 1;
                           $_SESSION['gB'][1][2] += 1;
                           $_SESSION['gB'][1][3] += 0;
                           $_SESSION['gB'][1][4] += 0;
                           $_SESSION['gB'][1][5] += $score23;
                           $_SESSION['gB'][1][6] += $score24;
                           $_SESSION['gB'][1][7] += $score23 - $score24;
                           $_SESSION['gB'][1][8] += 3;  
                           
                           $_SESSION['gB'][2][1] += 1;
                           $_SESSION['gB'][2][2] += 0;
                           $_SESSION['gB'][2][3] += 0;
                           $_SESSION['gB'][2][4] += 1;
                           $_SESSION['gB'][2][5] += $score24;
                           $_SESSION['gB'][2][6] += $score23;
                           $_SESSION['gB'][2][7] += $score24 - $score23;
                           $_SESSION['gB'][2][8] += 0;
              }      
               //score24 superieur a score23
                  else if( $_POST['score23']<$_POST['score24']){
                         $_SESSION['gB'][1][1] += 1;
                         $_SESSION['gB'][1][2] += 0;
                         $_SESSION['gB'][1][3] += 0;
                         $_SESSION['gB'][1][4] += 1;
                         $_SESSION['gB'][1][5] += $score23;
                         $_SESSION['gB'][1][6] += $score24;
                         $_SESSION['gB'][1][7] += $score23 - $score24;
                         $_SESSION['gB'][1][8] += 0;

                         $_SESSION['gB'][2][1] += 1;
                         $_SESSION['gB'][2][2] += 1;
                         $_SESSION['gB'][2][3] += 0;
                         $_SESSION['gB'][2][4] += 0;
                         $_SESSION['gB'][2][5] += $score24;
                         $_SESSION['gB'][2][6] += $score23;
                         $_SESSION['gB'][2][7] += $score24 - $score23;
                         $_SESSION['gB'][2][8] += 3;
                  } 
           //condition de poursuite pour l'equipes 1 et 2 si il y a match null
                  else {
                         $_SESSION['gB'][1][1] += 1;
                         $_SESSION['gB'][1][2] += 0;
                         $_SESSION['gB'][1][3] += 1;
                         $_SESSION['gB'][1][4] += 0;
                         $_SESSION['gB'][1][5] += $score23;
                         $_SESSION['gB'][1][6] += $score24;
                         $_SESSION['gB'][1][7] += 0;
                         $_SESSION['gB'][1][8] += 1;

                         $_SESSION['gB'][2][1] += 1;
                         $_SESSION['gB'][2][2] += 0;
                         $_SESSION['gB'][2][3] += 1;
                         $_SESSION['gB'][2][4] += 0;
                         $_SESSION['gB'][2][5] += $score24;
                         $_SESSION['gB'][2][6] += $score23;
                         $_SESSION['gB'][2][7] += 0;
                         $_SESSION['gB'][2][8] += 1;
                  }      
             }

?>
<link rel="stylesheet" type="text/css" href="traitement.css">
<figure id="div1">
       <video src="vid4.mp4" autoplay muted preload="auto" loop id="bgvid"></video>
</figure>
 <script type="text/javascript">
    function showdiv1() {
      document.getElementById("div1").style.visibility = "visible";
    }
    setTimeout("showdiv1()", 000); // aprés 15 sec

    function masquernotification()
{
  document.getElementById("div1").innerHTML="";
}
 window.setTimeout(masquernotification, 5000);


    function showDiv2() {
      document.getElementById("div2").style.visibility = "visible";
    }
    setTimeout("showDiv2()", 5000); // aprés 30 secs
   </script>
<body>
       <div id="div2">
<!--               lien de retour a la page tirage
 -->          <a href="tirage.php">Retour</a>

       <!-- table d'affichage des classements -->
                     <div class="ctr">
                       
                      <?php 
                                   for($i=0;$i<4;$i++){
                                   for($j=0;$j<4;$j++){
                                          $e1 = $_SESSION['gA'][$i][8];
                                          if($e1 >$_SESSION['gA'][$j][8]){
                                                 $tempon=$_SESSION['gA'][$i];
                                                 $_SESSION['gA'][$i]=$_SESSION['gA'][$j];
                                                 $_SESSION['gA'][$j]=$tempon;
                                                 }
                                          }
                                }
                                  
                                 
                             ?>

                             <table class="table5" border="">
                                           <tr>
                                                  <th class="aa" colspan="9">Groupe A</th>                                       
                                           <tr>
                                           <tr class="ss">
                                                  <td></td>
                                                  <td>MJ</td>
                                                  <td>MG</td>
                                                  <td>MN</td>
                                                  <td>MP</td>
                                                  <td>BP</td>
                                                  <td>BC</td>
                                                  <td>Dif</td>
                                                  <td>Point</td>
                                           </tr>
                                           <tr>
                                                  <td> <?= $_SESSION['gA'][0][0] ?> </td>
                                                  <td> <?= $_SESSION['gA'][0][1] ?> </td>
                                                  <td> <?= $_SESSION['gA'][0][2] ?> </td>
                                                  <td> <?= $_SESSION['gA'][0][3] ?> </td>
                                                  <td> <?= $_SESSION['gA'][0][4] ?> </td>
                                                  <td> <?= $_SESSION['gA'][0][5] ?> </td>
                                                  <td> <?= $_SESSION['gA'][0][6] ?> </td>
                                                  <td> <?= $_SESSION['gA'][0][7] ?> </td>
                                                  <td> <?= $_SESSION['gA'][0][8] ?> </td>
                                           </tr>      
                                           <tr>
                                                  <td> <?= $_SESSION['gA'][1][0]  ?></td>
                                                  <td> <?= $_SESSION['gA'][1][1] ?> </td>
                                                  <td> <?= $_SESSION['gA'][1][2] ?> </td>
                                                  <td> <?= $_SESSION['gA'][1][3] ?> </td>
                                                  <td> <?= $_SESSION['gA'][1][4] ?> </td>
                                                  <td> <?= $_SESSION['gA'][1][5] ?> </td>
                                                  <td> <?= $_SESSION['gA'][1][6] ?> </td>
                                                  <td> <?= $_SESSION['gA'][1][7] ?> </td>
                                                  <td> <?= $_SESSION['gA'][1][8] ?> </td>
                                           </tr>      
                                           <tr>
                                                  <td> <?= $_SESSION['gA'][2][0]  ?></td>
                                                  <td> <?= $_SESSION['gA'][2][1] ?> </td>
                                                  <td> <?= $_SESSION['gA'][2][2] ?> </td>
                                                  <td> <?= $_SESSION['gA'][2][3] ?> </td>
                                                  <td> <?= $_SESSION['gA'][2][4] ?> </td>
                                                  <td> <?= $_SESSION['gA'][2][5] ?> </td>
                                                  <td> <?= $_SESSION['gA'][2][6] ?> </td>
                                                  <td> <?= $_SESSION['gA'][2][7] ?> </td>
                                                  <td> <?= $_SESSION['gA'][2][8] ?> </td>       
                                           </tr>
                                           <tr>
                                                  <td> <?= $_SESSION['gA'][3][0]  ?></td>
                                                  <td> <?= $_SESSION['gA'][3][1] ?> </td>
                                                  <td> <?= $_SESSION['gA'][3][2] ?> </td>
                                                  <td> <?= $_SESSION['gA'][3][3] ?> </td>
                                                  <td> <?= $_SESSION['gA'][3][4] ?> </td>
                                                  <td> <?= $_SESSION['gA'][3][5] ?> </td>
                                                  <td> <?= $_SESSION['gA'][3][6] ?> </td>
                                                  <td> <?= $_SESSION['gA'][3][7] ?> </td>
                                                  <td> <?= $_SESSION['gA'][3][8] ?> </td>
                                                 
                                           </tr>            
                            </table>
                     </div>       
                     <br>
                     <br>
                     <br>

                     <div class="ctr">  
                               <?php 
                                   for($i=0;$i<4;$i++){
                                   for($j=0;$j<4;$j++){
                                          $e1 = $_SESSION['gB'][$i][8];
                                          if($e1 >$_SESSION['gB'][$j][8]){
                                                 $tempon=$_SESSION['gB'][$i];
                                                 $_SESSION['gB'][$i]=$_SESSION['gB'][$j];
                                                 $_SESSION['gB'][$j]=$tempon;
                                                 }
                                          }
                                }

                             ?> 
                            <table class="table6" border="1p">
                                           <tr>
                                                  <th class="aa" colspan="9">Groupe B</th>                                       
                                           <tr>
                                           <tr class="ss">
                                                  <td></td>
                                                  <td>MJ</td>
                                                  <td>MG</td>
                                                  <td>MN</td>
                                                  <td>MP</td>
                                                  <td>BP</td>
                                                  <td>BC</td>
                                                  <td>Dif</td>
                                                  <td>Point</td>
                                           </tr>
                                           <tr>
                                                  <td> <?= $_SESSION['gB'][0][0]  ?></td>
                                                  <td> <?= $_SESSION['gB'][0][1] ?> </td>
                                                  <td> <?= $_SESSION['gB'][0][2] ?> </td>
                                                  <td> <?= $_SESSION['gB'][0][3] ?> </td>
                                                  <td> <?= $_SESSION['gB'][0][4] ?> </td>
                                                  <td> <?= $_SESSION['gB'][0][5] ?> </td>
                                                  <td> <?= $_SESSION['gB'][0][6] ?> </td>
                                                  <td> <?= $_SESSION['gB'][0][7] ?> </td>
                                                  <td> <?= $_SESSION['gB'][0][8] ?> </td>
                                           </tr>      
                                           <tr>
                                                  <td> <?= $_SESSION['gB'][1][0]  ?></td>
                                                  <td> <?= $_SESSION['gB'][1][1] ?> </td>
                                                  <td> <?= $_SESSION['gB'][1][2] ?> </td>
                                                  <td> <?= $_SESSION['gB'][1][3] ?> </td>
                                                  <td> <?= $_SESSION['gB'][1][4] ?> </td>
                                                  <td> <?= $_SESSION['gB'][1][5] ?> </td>
                                                  <td> <?= $_SESSION['gB'][1][6] ?> </td>
                                                  <td> <?= $_SESSION['gB'][1][7] ?> </td>
                                                  <td> <?= $_SESSION['gB'][1][8] ?> </td>
                                           </tr>      
                                           <tr>
                                                  <td> <?= $_SESSION['gB'][2][0]  ?></td>
                                                  <td> <?= $_SESSION['gB'][2][1] ?> </td>
                                                  <td> <?= $_SESSION['gB'][2][2] ?> </td>
                                                  <td> <?= $_SESSION['gB'][2][3] ?> </td>
                                                  <td> <?= $_SESSION['gB'][2][4] ?> </td>
                                                  <td> <?= $_SESSION['gB'][2][5] ?> </td>
                                                  <td> <?= $_SESSION['gB'][2][6] ?> </td>
                                                  <td> <?= $_SESSION['gB'][2][7] ?> </td>
                                                  <td> <?= $_SESSION['gB'][2][8] ?> </td>  
                                           </tr>
                                           <tr>
                                                  <td> <?= $_SESSION['gB'][3][0] ?></td>
                                                  <td> <?= $_SESSION['gB'][3][1] ?> </td>
                                                  <td> <?= $_SESSION['gB'][3][2] ?> </td>
                                                  <td> <?= $_SESSION['gB'][3][3] ?> </td>
                                                  <td> <?= $_SESSION['gB'][3][4] ?> </td>
                                                  <td> <?= $_SESSION['gB'][3][5] ?> </td>
                                                  <td> <?= $_SESSION['gB'][3][6] ?> </td>
                                                  <td> <?= $_SESSION['gB'][3][7] ?> </td>
                                                  <td> <?= $_SESSION['gB'][3][8] ?> </td>
                                           </tr>            
                            </table>

                     </div>
                     <br>
                     <br>              
       </div2>
       <div class="">
             <!--  <php
                                  //DECLARATION DE VARIABLE
                           $equipe1 = $_SESSION['gA'][0][1]; 
                           $equipe2 = $_SESSION['gA'][1][1];
                           $equipe3 = $_SESSION['gA'][2][1]; 
                           $equipe4 = $_SESSION['gA'][3][1];
                     

                           //DEMI-FINAL
                           if ($equipe1==3) {
                            if ($equipe1==$equipe2) {
                                if ($equipe2==$equipe3) {
                                    if ($equipe3==$equipe4) {
                                          // usort($classement,'tempon');
                                        $_SESSION['tableDemie'][0][0] = $classement[0][0];
                                        $_SESSION['tableDemie'][1][0] = $classement[1][0];
                                    }
                                }
                            }
                     }
       
              ?>
               -->
               <a class="aa" href="demi.php">Qualification</a>
             
</body>       
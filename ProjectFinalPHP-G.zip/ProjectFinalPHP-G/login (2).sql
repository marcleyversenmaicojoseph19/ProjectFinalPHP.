-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 14, 2021 at 11:43 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.2.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `login`
--

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `email`, `password`) VALUES
(1, 'lilwest', 'lilwestking@gmail.com', '9af15b336e6a9619928537df30b2e6a2376569fcf9d7e773eccede65606529a0'),
(2, 'albert', 'jmtemitis@yahoo.fr', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4'),
(3, 'qwerty', 'marcleyversenmaicojoseph19@gmail.com', 'c1f330d0aff31c1c87403f1e4347bcc21aff7c179908723535f2b31723702525'),
(4, 'Haendel', 'satori@gmail.com', '8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918'),
(5, 'marcleyver', 'marcleyversenmaicojoseph19@gmail.com', '54c48611a91b2e1b23c6ee0669eaf2a2f272472dbdc3c266c0eff510faa98327'),
(6, 'maico', 'marcleyversenmaicojoseph19@gmail.com', '54c48611a91b2e1b23c6ee0669eaf2a2f272472dbdc3c266c0eff510faa98327'),
(7, 'Gadjouny', 'gadjounyc@gmail.com', '178a86b1cb3642edf727830bc25ea9d2bf236c651c2db04c1395cc49e10de96a'),
(8, 'Gadjouny', 'gadjounyc@gmail.com', '178a86b1cb3642edf727830bc25ea9d2bf236c651c2db04c1395cc49e10de96a'),
(9, 'Gadjouny', 'gadjounyc@gmail.com', '178a86b1cb3642edf727830bc25ea9d2bf236c651c2db04c1395cc49e10de96a'),
(10, 'Gadjouny', 'gadjounyc@gmail.com', '178a86b1cb3642edf727830bc25ea9d2bf236c651c2db04c1395cc49e10de96a'),
(11, 'nini', 'dooda@yahoo.fr', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4'),
(12, 'nini', 'dooda@yahoo.fr', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4'),
(13, 'nini', 'dooda@yahoo.fr', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4'),
(14, 'nini', 'dooda@yahoo.fr', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4'),
(15, 'nini', 'dooda@yahoo.fr', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4'),
(16, 'nini', 'dooda@yahoo.fr', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4'),
(17, 'nini', 'dooda@yahoo.fr', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4'),
(18, 'nini', 'dooda@yahoo.fr', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4'),
(19, 'nini', 'dooda@yahoo.fr', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4'),
(20, 'nini', 'dooda@yahoo.fr', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4'),
(21, 'nini', 'dooda@yahoo.fr', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4'),
(22, 'nini', 'dooda@yahoo.fr', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4'),
(23, 'nini', 'dooda@yahoo.fr', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4'),
(24, 'nini', 'dooda@yahoo.fr', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4'),
(25, 'nini', 'dooda@yahoo.fr', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4'),
(26, 'nini', 'dooda@yahoo.fr', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4'),
(27, 'nini', 'dooda@yahoo.fr', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4'),
(28, 'nini', 'dooda@yahoo.fr', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4'),
(29, 'nini', 'dooda@yahoo.fr', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4'),
(30, 'nini', 'dooda@yahoo.fr', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4'),
(31, 'nini', 'dooda@yahoo.fr', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4'),
(32, 'nini', 'dooda@yahoo.fr', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4'),
(33, 'nini', 'dooda@yahoo.fr', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4'),
(34, 'nini', 'dooda@yahoo.fr', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4'),
(35, 'nini', 'dooda@yahoo.fr', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4'),
(36, 'nini', 'dooda@yahoo.fr', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4'),
(37, 'nini', 'dooda@yahoo.fr', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4'),
(38, 'nini', 'dooda@yahoo.fr', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4'),
(39, 'nini', 'dooda@yahoo.fr', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4'),
(40, 'emma', 'johhdo', '9af15b336e6a9619928537df30b2e6a2376569fcf9d7e773eccede65606529a0'),
(41, 'jerry', 'jerry@gmail.com', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4'),
(42, 'Berlensky', 'berlensky@gmail.com', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4'),
(43, 'kiki', 'kiki@gmail.com', '9af15b336e6a9619928537df30b2e6a2376569fcf9d7e773eccede65606529a0'),
(44, 'CHERUSME Gadjouny', 'gadjounyc@gmail.com', '178a86b1cb3642edf727830bc25ea9d2bf236c651c2db04c1395cc49e10de96a');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

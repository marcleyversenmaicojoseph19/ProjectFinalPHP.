<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="logine.css" />
</head>
<body>
  <figure>
              <video src="vid5.mp4" autoplay muted preload="auto" loop id="bgvid"></video>
   </figure>
<?php
require('config.php');
if (isset($_REQUEST['username'], $_REQUEST['email'], $_REQUEST['password'])){
  // récupérer le nom d'utilisateur et supprimer les antislashes ajoutés par le formulaire
  $username = stripslashes($_REQUEST['username']);
  $username = mysqli_real_escape_string($conn, $username); 
  // récupérer l'email et supprimer les antislashes ajoutés par le formulaire
  $email = stripslashes($_REQUEST['email']);
  $email = mysqli_real_escape_string($conn, $email);
  // récupérer le mot de passe et supprimer les antislashes ajoutés par le formulaire
  $password = stripslashes($_REQUEST['password']);
  $password = mysqli_real_escape_string($conn, $password);
  //requéte SQL + mot de passe crypté
    $query = "INSERT into `user` (username, email, password)
              VALUES ('$username', '$email', '".hash('sha256', $password)."')";
  // Exécuter la requête sur la base de données
    $res = mysqli_query($conn, $query);
    if($res){
       echo "<div class='sucess'>
             <h3>Vous êtes inscrit avec succès.</h3>
             <p>Cliquez ici pour vous <a href='index.php'>Connecter</a></p>
       </div>";
    }
}else{
?>
  <div class="bdre">
    <form class="box" action="" method="post">
        <img src="ll.png" alt="logo" class="log">      
        <h1 class="box-title">S'inscrire</h1>
        <input type="text" class="box-input" name="username" placeholder="Nom d'utilisateur" required /><br><br>
        <input type="mail" class="box-input" name="email" placeholder="Email" required /><br><br>
        <input type="password" class="box-input" name="password" placeholder="Mot de passe" required /><br><br>
        <input type="submit" name="submit" value="S'inscrire" class="box-button" /><br><br>
        <span class="box-register">Déjà inscrit? <a href="index.php">Connectez-vous ici</a></span>
    </form>
  </div>  
<?php } ?>
</body>
</html>

 <?php
                        // $c=mysqli_connect('localhost','root','','login');
                        // //declaration des variable
                        // $nom=$_POST['username'];
                        // $code=$_POST['password'];
                        // //on cree la requete
                        // $req="insert into acces value('$nom','$code')";
                        // //envoie la requete
                        // $ex=$c->query($req);
                        // if($ex){
                        //     echo"mot de passe sauvegarder";
                        // }
                        // else{
                        //     echo"Sauvegarde echouee";
                       // }
                ?>


<?php
include "header.php";
?>
<?php 
// include "tirage.php";
?>  
<!-- <php
include "footer.php";
?>
 -->





















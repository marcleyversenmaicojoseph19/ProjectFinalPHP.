<?php
          require('config.php');
         session_start();

         $_SESSION['fait'] = 0; 
         if(isset($_SESSION['test']) && $_SESSION['test']==0){
              // header('location:./tirage.php');
       }else{
       header('location:./index.php');
       }
?>  
   
<!DOCTYPE html>   
<html lang="en">
<head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="tirage.css">
        <title>Document</title>
</head>
      
<body>
      
       <figure>
              <video src="vide.mp4" autoplay muted preload="auto" loop id="bgvid"></video>
       </figure>       
       <header>
                <div class="tete">
                </div>               
                <div class="entete">
                    <label class="ham" for="toggler">&#9776;</label>
                                    <input type="checkbox" id="toggler">

                                    <nav class="navigation"> 
                                          <h1 class="vv"> 
                                                    <?php echo $_SESSION['username']; ?>
                                                </h1>
                                            <a href="Acceuil.php">Acceuil</a>
                                            <a href="tirage.php">Tirage</a>
                                            <a href="logout.php">Déconnexion</a>
                                    </nav>
                </div>
                
        </header>


<article >
     <!-- table premier et declaration variable -->



     <!--  table de stockage des equipes avant le tirage-->
       <div class="tables">
              <div class="l1">
                     <table class="li">
                     <tr>
                            <th class="ss">GROUPE A</th>
                     </tr>    
                     <tr>
                            <td><img src="./foto/foto1/bra.png"width="30%" height="55vh"/><?php  echo "Bresil"?></td>
                     </tr>
                     <tr>
                            <td><img src="./foto/foto1/arg.png"width="30%" height="55vh"/><?php  echo"Argentine"?></td>
                     </tr>
                      </table>
              </div>

              <div class="l2">
                     <table class="lo">
                     <tr>
                            <th class="ss">GROUPE B</th>   
                     </tr>
                     <tr>
                            <td><img src="./foto/foto1/fra.png"width="30%" height="55vh"/><?php  echo"France"?></td>
                     </tr>
                     
                     <tr>
                            <td><img src="./foto/foto1/esp.png"width="30%" height="55vh"/><?php  echo"Espagne"?></td>
                     </tr>
                     <br>
              
                     </table> 
              </div>
              <div class="l3">       
           
                     <table class="le">
                            <tr>
                                   <th class="ss">GROUPE C</th>
                            </tr>
                            <tr>
                                   <td><img src="./foto/foto1/por.png"width="30%" height="55vh"/><?php  echo"Portugal"?></td>
                            </tr>
                            <tr>
                                   <td><img id="uu"src="./foto/foto1/ita.png"width="26%" height="55vh"/><?php  echo"Italie"?></td>
                            </tr>
                     </table>
              </div>
              <div class="l4">       
                     <table class="la">
                            <tr>
                                   <th class="ss">GROUPE D</th>
                            </tr>
                            <tr>
                                   <td><img src="./foto/foto1/all.png"width="28%" height="55vh"/><?php  echo"Allemagne"?></td>
                            </tr>
                            <tr>
                                   <td><img class="ii" src="./foto/foto1/hat.png"width="28%" height="75vh"/><?php  echo"Haiti"?></td>
                            </tr>
                     </table>
              </div> 
              <img src="ll.png" alt="logo" class="log">
              <form action="tirage1.php" method="POST">
              <input id="button" type="submit" value="Tirage" name="tirageEquipe">
              </form>      
       </div>     
<!-- fin de la premiere table -->

<?php 

     if( isset($_SESSION['gA'][0]) ){

?>
       <div class="classement">    
              <div class="tableTirage"> 
       <!-- table de stockage apres le tirage -->
              <table class="table2">
                     <thead>
                     <tr>
                            <th>Groupe A</th>
                            <th>Groupe B</th>
                     </tr>
                     </thead>

                     <tbody>
                     <tr class="tt">
                         <td><?php echo $_SESSION['gA'][0][0]?></td>
                         <td><?php echo $_SESSION['gB'][0][0]?></td>
                    </tr>
                    <tr class="yy">
                         <td><?php echo $_SESSION['gA'][1][0]?></td>
                         <td><?php echo $_SESSION['gB'][1][0]?></td>
                    </tr>
                    <tr class="tt">
                         <td><?php echo $_SESSION['gA'][2][0]?></td>
                         <td><?php echo $_SESSION['gB'][2][0]?></td>
                     </tr>
                     <tr class="yy">
                          <td><?php echo $_SESSION['gA'][3][0]?></td>
                         <td><?php echo $_SESSION['gB'][3][0]?></td>
                     </tr>
                </tbody>
         </table>
  </div>


<!--fin de la deuxieme table  -->
<!--  table des match a effectuer-->
<!-- match table A -->


   <div class="classement1">
          
           <table  class="table3">
                  <thead>
                         <tr>
                                <th class="ii"  colspan="4">Groupe A</th>
                         </tr>      
                 </thead>
                 <tbody>
                          <tr class=>
                                <th class="uu">Matchs</th> 
                                <th class="uu">Affiche</th>
                                <th class="uu">Score</th> 
                                <th class="uu">Soumettre</th>   
                          </tr>
                          <tr class="e">
                            <form method="post" action="traitement.php">

                                <td class="ee"><input type="number" name="match1" value="1" id="mm" readonly ></td>
                                <td class="ee"><?php  echo $_SESSION['gA'][0][0] . 'vs' .$_SESSION['gA'][1][0] ?></td>
                                <td>
                                      <?php
                                       //ceci pour indiquer que le score est enregistrer 
                                        if ( isset($_SESSION['match1']) ) {
                                                    echo '<input disabled type="text" style="width:30px" value='.$_SESSION['match1'][0].'>';
                                                    echo '<input disabled type="text" style="width:30px" value='.$_SESSION['match1'][1].'>';
                                             }else{
                                                    ?>
                                                    <input type="number" min="0" max="15" style="width:30px" name="score1" id="score" required>
                                                    <input type="number" min="0" max="15" style="width:30px" name="score2" id="score" required>
                                          <?php
                                                } // fermer else 
                                          ?>  
                                </td>
                                <td>
                                        <button  <?php
                                              if ( isset($_SESSION['match1']) ) {
                                                    echo 'class="but cacherBouton" ';
                                             }else{
                                                    echo 'class="but" ';
                                             }
                                             ?>
                                             type="submit"
                                             name="">valider
                                      </button>
                                </td>
                         </form>

                         </tr>
                         <tr>
                             <form action="traitement.php" method="post">
                                <td class="uu"><input type="number" name="match2" value="2" id="mm" readonly ></td>
                                <td class="uu"><?php echo $_SESSION['gA'][2][0] . 'vs'   .$_SESSION['gA'][3][0]?>  </td>
                                <td>
                                <?php
                                 //ceci pour indiquer que le score est enregistrer 
                                             if ( isset($_SESSION['match2']) ) {
                                                    echo '<input disabled type="text" style="width:30px" value='.$_SESSION['match2'][0].'>';
                                                    echo '<input disabled type="text" style="width:30px" value='.$_SESSION['match2'][1].'>';
                                             }else{
                                                    ?>
                                                    <input type="number" min="0" max="15" style="width:30px" name="score3" id="score" required>
                                                    <input type="number" min="0" max="15" style="width:30px" name="score4" id="score" required>
                                                    <?php
                                                           } // fermer else 
                                                    ?>  
                                             </td>
                                             <td>
                                                     <button  <?php
                                                           if ( isset($_SESSION['match2']) ) {
                                                                  echo 'class="but2 cacherBouton2" ';
                                                           }else{
                                                                  echo 'class="but2" ';
                                                           }
                                                           ?>
                                                           type="submit"
                                                           name="">valider
                                                  </button>
                                             </td>
                               </form> 
                                          

                         </tr>
                          <tr>
                             <form action="traitement.php" method="post">
                                <td class="ee"><input type="number" name="match3" value="3" id="mm" readonly ></td>
                                <td class="ee"><?php echo $_SESSION['gA'][0][0] . 'vs'   .$_SESSION['gA'][2][0]?></td>
                                <td>
                                <?php
                                 //ceci pour indiquer que le score est enregistrer 
                                       if ( isset($_SESSION['match3']) ) {
                                                    echo '<input disabled type="text" style="width:30px" value='.$_SESSION['match3'][0].'>';
                                                    echo '<input disabled type="text" style="width:30px" value='.$_SESSION['match3'][1].'>';
                                      }else{
                                ?> 
                                       <input type="number" min="0" max="15" style="width:30px" name="score5" id="score" required>
                                       <input type="number" min="0" max="15" style="width:30px" name="score6" id="score" required>
                                 <?php
                                      }// fermer else 
                                 ?>      
                                </td>
                                 <td>
                                                     <button  <?php
                                                           if ( isset($_SESSION['match3']) ) {
                                                                  echo 'class="but3 cacherBouton3" ';
                                                           }else{
                                                                  echo 'class="but3" ';
                                                           }
                                                           ?>
                                                           type="submit"
                                                           name="">valider
                                                  </button>
                                             </td>
                               </form> 
                         </tr>
                         <tr>
                            <form action="traitement.php" method="post">
                                <td class="uu"><input type="number" name="match4" value="4" id="mm" readonly ></td>
                                <td class="uu"><?php echo $_SESSION['gA'][1][0] . 'vs'   .$_SESSION['gA'][3][0]?></td>
                                <td>
                                <?php
                                 //ceci pour indiquer que le score est enregistrer 
                                       if ( isset($_SESSION['match4']) ) {
                                                    echo '<input disabled type="text" style="width:30px" value='.$_SESSION['match4'][0].'>';
                                                    echo '<input disabled type="text" style="width:30px" value='.$_SESSION['match4'][1].'>';
                                      }else{
                                ?> 
                                        <input type="number" min="0" max="15" style="width:30px" name="score7" id="score" required>
                                        <input type="number" min="0" max="15" style="width:30px" name="score8" id="score" required>
                                       <?php
                                             }//fin else
                                       ?>  
                                </td>
                                  <td>
                                <button  <?php
                                              if ( isset($_SESSION['match4']) ) {
                                                    echo 'class="but4 cacherBouton4" ';
                                             }else{
                                                    echo 'class="but4" ';
                                             }
                                             ?>
                                             type="submit"
                                             name="">valider
                                      </button>
                                </td>
                         </form>
                         </tr>
                         <tr>
                            <form action="traitement.php" method="post">
                                <td class="ee"><input type="number" name="match5" value="5" id="mm" readonly ></td>
                                <td class="ee"><?php echo $_SESSION['gA'][0][0] . 'vs'   .$_SESSION['gA'][3][0]?></td>
                                <td>
                                <?php
                                //ceci pour indiquer que le score est enregistrer 
                                       if ( isset($_SESSION['match5']) ) {
                                                    echo '<input disabled type="text" style="width:30px" value='.$_SESSION['match5'][0].'>';
                                                    echo '<input disabled type="text" style="width:30px" value='.$_SESSION['match5'][1].'>';
                                      }else{
                                ?> 
                                       <input type="number" min="0" max="15" style="width:30px" name="score9" id="score" required>
                                       <input type="number" min="0" max="15" style="width:30px" name="score10" id="score" required>
                               <?php
                                      }//fin else
                               ?>                 
                                </td>
                                     <td>
                                       <button  <?php
                                                     if ( isset($_SESSION['match5']) ) {
                                                           echo 'class="but5 cacherBouton5" ';
                                                    }else{
                                                           echo 'class="but5" ';
                                                    }
                                                    ?>
                                                    type="submit"
                                                    name="">valider
                                             </button>
                                </td>
                         </form>
                          </tr>
                          <tr>
                            <form action="traitement.php" method="post">
                                <td class="uu"><input type="number" name="match6" value="6" id="mm" readonly ></td>
                                <td class="uu"><?php echo $_SESSION['gA'][1][0] . 'vs'   .$_SESSION['gA'][2][0]?></td>  
                                 <td>
                                 <?php
                                  //ceci pour indiquer que le score est enregistrer 
                                       if ( isset($_SESSION['match6']) ) {
                                                    echo '<input disabled type="text" style="width:30px" value='.$_SESSION['match6'][0].'>';
                                                    echo '<input disabled type="text" style="width:30px" value='.$_SESSION['match6'][1].'>';
                                      }else{
                                ?> 
                                       <input name="score11" id="score" min="0" max="15" style="width:30px" required>
                                       <input name="score12" id="score" min="0" max="15" style="width:30px" required>
                                <?php
                                      }//fin else
                                 ?>
                                </td>
                                 </td>
                                     <td>
                                       <button  <?php
                                                     if ( isset($_SESSION['match6']) ) {
                                                           echo 'class="but6 cacherBouton6" ';
                                                    }else{
                                                           echo 'class="but6" ';
                                                    }
                                                    ?>
                                                    type="submit"
                                                    name="">valider
                                             </button>
                                </td>
                           </form>
                         </tr>
                    </tbody> 
           </table>
    </div>


<!-- fin table A -->
<!-- match a effectuer table B -->


    <div class="classement2">
           <table  class="table4">
                  <thead>
                         <tr>
                                <th class="ii" colspan="4">Groupe B</th> 
                         </tr>
                  </thead>
                  <tbody>
                         <tr>
                                <th class="uu">Matchs</th> 
                                <th class="uu">Affiche</th>
                                <th class="uu">Score</th>
                                <th class="uu">Soumettre</th>  
                         </tr>
                         <tr>
                            <form action="traitement.php" method="post">
                                 <td class="ee"><input type="number" name="match7" value="7" id="mm" readonly ></td>
                                 <td class="ee"><?php  echo $_SESSION['gB'][0][0] . 'vs'   .$_SESSION['gB'][1][0] ?></td>
                                 <td>
                                 <?php
                                  //ceci pour indiquer que le score est enregistrer 
                                       if ( isset($_SESSION['match7']) ) {
                                                    echo '<input disabled type="text" style="width:30px" value='.$_SESSION['match7'][0].'>';
                                                    echo '<input disabled type="text" style="width:30px" value='.$_SESSION['match7'][1].'>';
                                      }else{
                                ?> 
                                       <input name="score13"  id="score" type="number" min="0" max="15" style="width:30px" required>
                                       <input name="score14"  id="score"type="number" min="0" max="15" style="width:30px" required>
                               <?php
                                      }//fin else
                                ?>                
                                </td>
                                 <td>
                                      <button 
                                  <?php
                                              if ( isset($_SESSION['match7']) ) {
                                                    echo 'class="but7 cacherBouton7" ';
                                             }else{
                                                    echo 'class="but7" ';
                                             }       
                                  ?>
                                             type="submit"
                                             name="">valider
                                </button>
                              </td>
                          </form>
                         </tr>
                         <tr>
                            <form action="traitement.php" method="post">
                                 <td class="uu"><input type="number" name="match8" value="8" id="mm" readonly ></td>
                                 <td class="uu"><?php echo $_SESSION['gB'][2][0] . 'vs'   .$_SESSION['gB'][3][0]?>  </td>
                                 <td>
                                 <?php
                                  //ceci pour indiquer que le score est enregistrer  dans les casiers 
                                       if ( isset($_SESSION['match8']) ) {
                                                    echo '<input disabled type="text" style="width:30px" value='.$_SESSION['match8'][0].'>';
                                                    echo '<input disabled type="text" style="width:30px" value='.$_SESSION['match8'][1].'>';
                                      }else{
                                ?> 
                                        <input name="score15" id="score" type="number" min="0" max="15" style="width:30px" required>       
                                        <input name="score16" id="score" type="number" min="0" max="15" style="width:30px" required>
                                    <?php
                                           }//fin else
                                     ?>           
                                 </td>
                                 <td>
                                      <button 
                                  <?php
                                              if ( isset($_SESSION['match8']) ) {
                                                    echo 'class="but8 cacherBouton8" ';
                                             }else{
                                                    echo 'class="but8" ';
                                             }       
                                  ?>
                                             type="submit"
                                             name="">valider
                               </button>
                              </td>
                          </form>
                         </tr>
                         <tr>
                            <form action="traitement.php" method="post">
                                <td class="ee"><input type="number" name="match9" value="9" id="mm" readonly ></td>
                                <td class="ee"><?php echo $_SESSION['gB'][0][0] . 'vs'   .$_SESSION['gB'][2][0]?></td>
                                <td>
                                       <?php
                                             //ceci pour indiquer que le score est enregistrer 
                                             if ( isset($_SESSION['match9']) ) {
                                                    echo '<input disabled type="text" style="width:30px" value='.$_SESSION['match9'][0].'>';
                                                    echo '<input disabled type="text" style="width:30px" value='.$_SESSION['match9'][1].'>';
                                             }else{
                                        ?>
                                       <input name="score17" id="score" type="number" min="0"max="15" style="width:30px" required>      
                                       <input name="score18" id="score" type="number" min="0"max="15" style="width:30px" required>
                                       <?php
                                            }//fin else
                                        ?>      
                                </td>
                                <td>
                                      <button 
                                  <?php
                                              if ( isset($_SESSION['match9']) ) {
                                                    echo 'class="but9 cacherBouton9" ';
                                             }else{
                                                    echo 'class="but9" ';
                                             }       
                                  ?>
                                             type="submit"
                                             name="">valider
                               </button>
                              </td>
                           </form>
                         </tr>
                         <tr>
                            <form action="traitement.php" method="post">
                                <td class="uu"><input type="number" name="match10" value="10" id="mm" readonly ></td>
                                <td class="uu"><?php echo $_SESSION['gB'][1][0] . 'vs'   .$_SESSION['gB'][3][0]?></td>
                                <td>  <?php
                                             //ceci pour indiquer que le score est enregistrer 
                                             if ( isset($_SESSION['match10']) ) {
                                                    echo '<input disabled type="text" style="width:30px" value='.$_SESSION['match10'][0].'>';
                                                    echo '<input disabled type="text" style="width:30px" value='.$_SESSION['match10'][1].'>';
                                             }else{
                                        ?>

                                       <input name="score19" id="score" type="number" min="0" max="15" style="width:30px" required>
                                       <input name="score20" id="score" type="number" min="0" max="15" style="width:30px" required>
                                      <?php
                                             }
                                      ?>        
                                </td>
                                <td>
                                      <button 
                                  <?php
                                              if ( isset($_SESSION['match10']) ) {
                                                    echo 'class="but10 cacherBouton10" ';
                                             }else{
                                                    echo 'class="but10" ';
                                             }       
                                  ?>
                                             type="submit"
                                             name="">valider
                               </button>
                              </td>
                         </form>
                         </tr>

                         <tr>
                            <form action="traitement.php" method="post">
                                <td class="ee"><input type="number" name="match11" value="11" id="mm" readonly ></td>
                                <td class="ee"><?php echo $_SESSION['gB'][0][0] . 'vs'   .$_SESSION['gB'][3][0]?></td>
                                 <td>
                                 <?php
                                             //ceci pour indiquer que le score est enregistrer 
                                             if ( isset($_SESSION['match11']) ) {
                                                    echo '<input disabled type="text" style="width:30px" value='.$_SESSION['match11'][0].'>';
                                                    echo '<input disabled type="text" style="width:30px" value='.$_SESSION['match11'][1].'>';
                                             }else{
                                        ?>
                                       <input name="score21" id="score" type="number" min="0" max="15" style="width:30px" required>
                                       <input name="score22" id="score" type="number" min="0" max="15" style="width:30px" required>
                                             <?php
                                             }
                                             ?>
                                </td>
                                   <td>
                                      <button 
                                          <?php
                                              if ( isset($_SESSION['match11']) ) {
                                                    echo 'class="but11 cacherBouton11" ';
                                             }else{
                                                    echo 'class="but11" ';
                                             }       
                                           ?>
                                             type="submit"
                                             name="">valider
                               </button>
                              </td>
                                <td>
                            </form>   
                         </tr>

                         <tr>
                            <form action="traitement.php" method="post">
                                <td class="uu"><input type="number" name="match12" value="12" id="mm" readonly ></td>
                                <td class="uu"><?php echo $_SESSION['gB'][1][0] . 'vs'   .$_SESSION['gB'][2][0]?></td>
                                <td>
                                <?php
                                             //ceci pour indiquer que le score est enregistrer 
                                             if ( isset($_SESSION['match12']) ) {
                                                    echo '<input disabled type="text" style="width:30px" value='.$_SESSION['match12'][0].'>';
                                                    echo '<input disabled type="text" style="width:30px" value='.$_SESSION['match12'][1].'>';
                                             }else{
                                 ?>
                                        <input name="score23" id="score" type="number" min="0" max="15" style="width:30px" required>
                                        <input name="score24" id="score" type="number" min="0" max="15" style="width:30px" required> 
                                       <?php
                                             }
                                             ?>  
                                </td>
                              <td>
                                      <button 
                                  <?php
                                              if ( isset($_SESSION['match12']) ) {
                                                    echo 'class="but12 cacherBouton12" ';
                                             }else{
                                                    echo 'class="but12" ';
                                             }       
                                  ?>
                                             type="submit"
                                             name="">valider
                               </button>
                              </td>
                              </form>
                         </tr>
                  </tbody>
           </table>
       </div>

    </div>

       <div class="bb">
              <a  href="traitement.php">Classement</a>
       </div>
<?php   
}
?>   
       
<!-- fin table B -->

<!--scripts pour le verrouillage des boutons apres la validation des scores -->
       
              <script>
              // code javascript pour disable button1
              let boutonValider = document.querySelector('button.cacherBouton');       
              boutonValider.setAttribute('disabled',"");
              </script>

              <script>
              // code javascript pour disable button2
              let boutonValider2 = document.querySelector('button.cacherBouton2');       
              boutonValider2.setAttribute('disabled',"");
              </script>

              <script>
              // code javascript pour disable button3
              let boutonValider3 = document.querySelector('button.cacherBouton3');       
              boutonValider3.setAttribute('disabled',"");
              </script>

              <script>
              // code javascript pour disable button4
              let boutonValider4 = document.querySelector('button.cacherBouton4');       
              boutonValider4.setAttribute('disabled',"");
              </script>

              <script>
              // code javascript pour disable button5
              let boutonValider5 = document.querySelector('button.cacherBouton5');       
              boutonValider5.setAttribute('disabled',"");
              </script>

              <script>
              // code javascript pour disable button6
              let boutonValider6 = document.querySelector('button.cacherBouton6');       
              boutonValider6.setAttribute('disabled',"");
              </script>
              <!-- fin des scripts pour la table groupe A-->

              <!-- debut script pour la table groupe B -->
              <script>
              // code javascript pour disable button7
              let boutonValider7 = document.querySelector('button.cacherBouton7');       
              boutonValider7.setAttribute('disabled',"");
              </script>

              <script>
              // code javascript pour disable button8
              let boutonValider8 = document.querySelector('button.cacherBouton8');       
              boutonValider8.setAttribute('disabled',"");
              </script>

              <script>
              // code javascript pour disable button9
              let boutonValider9 = document.querySelector('button.cacherBouton9');       
              boutonValider9.setAttribute('disabled',"");
              </script>

              <script>
              // code javascript pour disable button10
              let boutonValider10 = document.querySelector('button.cacherBouton10');       
              boutonValider10.setAttribute('disabled',"");
              </script>

              <script>
              // code javascript pour disable button11
              let boutonValider11 = document.querySelector('button.cacherBouton11');       
              boutonValider11.setAttribute('disabled',"");
              </script>

              <script>
              // code javascript pour disable button12
              let boutonValider12 = document.querySelector('button.cacherBouton12');       
              boutonValider12.setAttribute('disabled',"");
              </script>

    </body>
</html>
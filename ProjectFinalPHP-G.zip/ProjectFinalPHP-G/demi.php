<?php
       session_start();

       if(!empty($_SESSION['matches1'])){

              if($_SESSION['matches1'][0] > $_SESSION['matches1'][1]){

                     $_SESSION['eq1Enfinal'] = $eq1Enfinal = $_SESSION['gA'][0][0];
                     $_SESSION['eq1EnPetitFinal'] = $eq1EnPetitFinal = $_SESSION['gB'][1][0];

              }else if($_SESSION['matches1'][0] < $_SESSION['matches1'][1]){

                     $_SESSION['eq1Enfinal'] = $eq1Enfinal = $_SESSION['gB'][1][0];
                     $_SESSION['eq1EnPetitFinal'] = $eq1EnPetitFinal = $_SESSION['gA'][0][0];
              }

       }else{
              $_SESSION['eq1Enfinal'] = $eq1Enfinal = "";
              $_SESSION['eq1EnPetitFinal'] = $eq1EnPetitFinal = "";
       }


       if(!empty($_SESSION['matches2'])){

              if($_SESSION['matches2'][0] > $_SESSION['matches2'][1]){

                     $_SESSION['eq2Enfinal'] = $eq2Enfinal = $_SESSION['gB'][0][0];
                     $_SESSION['eq2EnPetitFinal'] = $eq2EnPetitFinal = $_SESSION['gA'][1][0];

              }else if($_SESSION['matches2'][0] < $_SESSION['matches2'][1]){

                     $_SESSION['eq2Enfinal'] = $eq2Enfinal = $_SESSION['gA'][1][0];
                     $_SESSION['eq2EnPetitFinal'] = $eq2EnPetitFinal = $_SESSION['gB'][0][0];
              }

       }else{
              $_SESSION['eq2Enfinal'] = $eq2Enfinal = "";
              $_SESSION['eq2EnPetitFinal'] = $eq2EnPetitFinal = "";
       }
       
 ?> 
      <!-- lien de retour -->
 <link rel="stylesheet" type="text/css" href="demi.css">
 <a href="traitement.php">Retour</a>
           <!-- fin lien de retour -->
       <div class="tb0">
             <table class="tb1">            
                            <tr>
                                   <th colspan="5">Demi-final</th>
                            </tr>
                            <tr>
                                   <form action="demi.php" method="POST">
                                          <td class="bb">
                                                 <input style=" width: 30px; text-align: center;" type="number" name="matches1" value="1" readonly>
                                          </td> 
                                          <td class="bb">
                                                 <?php echo $_SESSION['gA'][0][0] ?> 
                                          </td>
                                          <td class="bb">
                                                <?php
                                                      //ceci pour indiquer que le score est enregistrer 
                                                            if ( isset($_SESSION['matches1']) ) {
                                                                         echo '<input disabled type="number" style="width:30px" value='.$_SESSION['matches1'][0].'>';
                                                                         echo '<input disabled type="number" style="width:30px" value='.$_SESSION['matches1'][1].'>';
                                                           }else{
                                                                     ?> 
                                                                                <input name="scoD1" type="number" min="0"max="15" style="width:30px" required> 
                                                                                 <span>vs</span> 
                                                                                <input name="scoD2" type="number" min="0"max="15" style="width:30px" required>
                                                                      <?php
                                                                                }// fermer else

                                                                       ?>
                 
                                                 </td>
                                                 <td class="bb">
                                                                     <?php echo $_SESSION['gB'][1][0] ?>
                                                        
                                                 </td>
                                                 <td class="bb">
                                                             <button  
                                                                     <?php
                                                                          if ( isset($_SESSION['matches1']) ) {
                                                                                echo 'class="butt1 cacherButton" ';
                                                                         }else{
                                                                                echo 'class="butt1" ';
                                                                         }
                                                                      ?>
                                                                         type="submit"
                                                                         name="">valider
                                                            </button>
                                   
                                                 </td>
                                   </form>       
                            </tr> 
                            <tr>
                                   <form action="demi.php" method="POST"> 
                                                 <td class="bb2">
                                                        <input style=" width: 30px; text-align: center;" type="number" name="matches2" value="2" readonly>
                                                 </td>
                                                 <td class="bb2">
                                                        <?php echo $_SESSION['gB'][0][0] ?> 
                                                 </td>
                                                 <td class="bb2">
                                                        <?php
                                                             //ceci pour indiquer que le score est enregistrer 
                                                                   if ( isset($_SESSION['matches2']) ) {
                                                                                echo '<input disabled type="number" style="width:30px" value='.$_SESSION['matches2'][0].'>';
                                                                                echo '<input disabled type="number" style="width:30px" value='.$_SESSION['matches2'][1].'>';
                                                                  }else{
                                                        ?> 
                                                                  <input name="scoD3" type="number" min="0"max="15" style="width:30px" required> 
                                                                   <span>vs</span> 
                                                                  <input name="scoD4" type="number" min="0"max="15" style="width:30px" required>
                                                        <?php
                                                                  }// fermer else 
                                                        ?>           
                                                </td>
                                                <td class="bb2"> 
                                                         <?php echo $_SESSION['gA'][1][0] ?>
                                                 
                                                </td>
                                                <td class="bb2">
                                                              <button 
                                                                     <?php
                                                                          if ( isset($_SESSION['matches2']) ) {
                                                                                echo 'class="butt2 cacherButton2" ';
                                                                         }else{
                                                                                echo 'class="butt2" ';
                                                                         }
                                                                      ?>
                                                                         type="submit"
                                                                         name="">valider
                                                             </button>
                                                </td>
                                      </form>       
                                </tr>   
                        </table>
                </div>       
              

                <?php
                      if(isset($_POST['matches1']) and isset($_POST['scoD1']) and isset($_POST['scoD2']))
                         {
                              // match ---NOM EQUIPE
                             $matches1 = [$_POST['scoD1'], $_POST['scoD2']];
                             $_SESSION['matches1'] = $matches1;

                             $numero = $_POST['matches1']; //recuperer numero match
                             $nom= 'match'.$numero; //former un nom dynamiquement pour chaque match             
                                   
                                    $i = 0; 
                                    $index = [];
                                    $valeurs = [];
                                    foreach ($_POST as $key => $value) {
                                           $index[$i] = $key;
                                           $valeurs[$i] = $value;
                                           $i+=1;

                                    }
                                    $equipe1 = $index[1];
                                    $equipe2 = $index[2];

                                    $scoD1 = $valeurs[1];
                                    $scoD2 = $valeurs[2];
                                //permet de comparer les deux equipes
                                    for($i=0; $i<4; $i++){
                                           if($_SESSION['gA'][$i][0] == $equipe1){
                                                  $indice1 = $i;
                                                  echo($_SESSION['gA'][$indice1][0]);

                                    
                                           }                            
                                    }
                                    //permet de comparer les deux equipes
                                    for($i=0; $i<4; $i++){
                                           if($_SESSION['gA'][$i][0] == $equipe1){
                                                  $indice1 = $i;
                                                  echo($_SESSION['gA'][$indice1][0]);

                                           }                            
                                    }
                                   // permet de comparer les deux equipes
                                    for ($z=0; $z<4; $z++) { 
                                           if($_SESSION['gA'][$z][0] == $equipe2){
                                                  $indice2 = $z;
                                                  echo($_SESSION['gA'][$indice2][0]);
                                           }
                            
                            }
                          }    



                     if(isset($_POST['matches2']) and isset($_POST['scoD3']) and isset($_POST['scoD4']))
                         {
                              // match ---NOM EQUIPE
                             $matches2 = [$_POST['scoD3'], $_POST['scoD4']];
                             $_SESSION['matches2'] = $matches2;

                             $numero = $_POST['matches2']; //recuperer numero match
                             $nom= 'match'.$numero; //former un nom dynamiquement pour chaque match             
                                   
                                    $i = 0; 
                                    $index = [];
                                    $valeurs = [];
                                    foreach ($_POST as $key => $value) {
                                           $index[$i] = $key;
                                           $valeurs[$i] = $value;
                                           $i+=1;

                                    }
                                    $equipe1 = $index[1];
                                    $equipe2 = $index[2];

                                    $scoD3 = $valeurs[1];
                                    $scoD4 = $valeurs[2];
                                //permet de comparer les deux equipes
                                    for($i=0; $i<4; $i++){
                                           if($_SESSION['gA'][$i][0] == $equipe1){
                                                  $indice1 = $i;
                                                  echo($_SESSION['gA'][$indice1][0]);

                                    
                                           }                            
                                    }
                                    //permet de comparer les deux equipes
                                    for($i=0; $i<4; $i++){
                                           if($_SESSION['gA'][$i][0] == $equipe1){
                                                  $indice1 = $i;
                                                  echo($_SESSION['gA'][$indice1][0]);

                                           }                            
                                    }
                                   // permet de comparer les deux equipes
                                    for ($z=0; $z<4; $z++) { 
                                           if($_SESSION['gA'][$z][0] == $equipe2){
                                                  $indice2 = $z;
                                                  echo($_SESSION['gA'][$indice2][0]);
                                           }
                                    }
                
                     }    
                    

                ?>

       <div class="tb00">         
              <table class="tb3">
                     <tr>
                            <th colspan="5">Petit-Final</th>
                     </tr>
                     <tr>
                                  <form action="" method="POST">
                                         <td class="bb"><input style=" width: 30px; text-align: center;" type="" name="matches4"></td>
                                         <td class="bb"><?= $_SESSION['eq1EnPetitFinal'] ?></td>
                                         <td class="bb">
                                                    <?php
                                                      //ceci pour indiquer que le score est enregistrer 
                                                            if ( isset($_SESSION['matches4']) ) {
                                                                         echo '<input disabled type="number" style="width:30px" value='.$_SESSION['matches4'][0].'>';
                                                                         echo '<input disabled type="number" style="width:30px" value='.$_SESSION['matches4'][1].'>';
                                                           }else{
                                                     ?> 
                                                           <input name="scoD7" type="number" min="0"max="15" style="width:30px" required> 
                                                            <span>vs</span> 
                                                           <input name="scoD8" type="number" min="0"max="15" style="width:30px" required>
                                                                    <?php
                                                                         }// fermer else 
                                                                    ?>           
                                         </td>
                                         <td class="bb">
                                                                    <?= $_SESSION['eq2EnPetitFinal'] ?>    
                                         </td>
                                         <td class="bb">
                                                             <button 
                                                                     <?php
                                                                          if ( isset($_SESSION['matches3']) ) {
                                                                                echo 'class="butt3 cacherButton3" ';
                                                                         }else{
                                                                                echo 'class="butt3" ';
                                                                         }
                                                                      ?>
                                                                         type="submit"
                                                                         name="">valider
                                                             </button>
                                         </td>
                                  </form>

                     </tr>
              </table>

                  <?php
                         if(isset($_POST['matches4']) and isset($_POST['scoD7']) and isset($_POST['scoD8']))
                         {
                              // match ---NOM EQUIPE
                             $matches4 = [$_POST['scoD7'], $_POST['scoD8']];
                             $_SESSION['matches4'] = $matches4;

                             $numero = $_POST['matches4']; //recuperer numero match
                             $nom= 'match'.$numero; //former un nom dynamiquement pour chaque match             
                                   
                                    $i = 0; 
                                    $index = [];
                                    $valeurs = [];
                                    foreach ($_POST as $key => $value) {
                                           $index[$i] = $key;
                                           $valeurs[$i] = $value;
                                           $i+=1;

                                    }
                                    $equipe1 = $index[1];
                                    $equipe2 = $index[2];

                                    $scoD7 = $valeurs[1];
                                    $scoD8 = $valeurs[2];
                                //permet de comparer les deux equipes
                                    for($i=0; $i<4; $i++){
                                           if($_SESSION['gA'][$i][0] == $equipe1){
                                                  $indice1 = $i;
                                                  echo($_SESSION['gA'][$indice1][0]);

                                    
                                           }                            
                                    }
                                    //permet de comparer les deux equipes
                                    for($i=0; $i<4; $i++){
                                           if($_SESSION['gA'][$i][0] == $equipe1){
                                                  $indice1 = $i;
                                                  echo($_SESSION['gA'][$indice1][0]);

                                           }                            
                                    }
                                   // permet de comparer les deux equipes
                                    for ($z=0; $z<4; $z++) { 
                                           if($_SESSION['gA'][$z][0] == $equipe2){
                                                  $indice2 = $z;
                                                  echo($_SESSION['gA'][$indice2][0]);
                                           }
                                    }
                
                     }    
                    
 
              ?>  
       </div>       

       <div class="tb01">         
               <table class="tb2">
                     <tr>
                            <th colspan="5">Final</th>
                     </tr>
                     <tr>
                                 <form action="" method="POST">
                                         <td class="bb"><input style=" width: 30px; text-align: center;" type="" name="matches3" value=""></td>
                                         <td class="bb"><?= $_SESSION['eq1Enfinal'] ?></td>
                                         <td class="bb">
                                          <?php
                                                      //ceci pour indiquer que le score est enregistrer 
                                                            if ( isset($_SESSION['matches3']) ) {
                                                                         echo '<input disabled type="number" style="width:30px" value='.$_SESSION['matches3'][0].'>';
                                                                         echo '<input disabled type="number" style="width:30px" value='.$_SESSION['matches3'][1].'>';
                                                           }else{
                                                     ?> 
                                                           <input name="scoD5" type="number" min="0"max="15" style="width:30px" required> 
                                                            <span>vs</span> 
                                                           <input name="scoD6" type="number" min="0"max="15" style="width:30px" required>
                                                      <?php
                                                           }// fermer else 
                                                      ?>           
                                         </td>
                                         <td class="bb"><?= $_SESSION['eq2Enfinal'] ?></td>
                                         <td class="bb">
                                                             <button 
                                                                     <?php
                                                                          if ( isset($_SESSION['matches4']) ) {
                                                                                echo 'class="butt4 cacherButton4" ';
                                                                         }else{
                                                                                echo 'class="butt4" ';
                                                                         }
                                                                      ?>
                                                                         type="submit"
                                                                         name="">valider
                                                             </button>
                                        </td>
                                 </form>
                     </tr>
              </table>
              <?php
                         if(isset($_POST['matches3']) and isset($_POST['scoD5']) and isset($_POST['scoD6']))
                         {
                              // match ---NOM EQUIPE
                             $matches3 = [$_POST['scoD5'], $_POST['scoD6']];
                             $_SESSION['matches3'] = $matches3;

                             $numero = $_POST['matches3']; //recuperer numero match
                             $nom= 'match'.$numero; //former un nom dynamiquement pour chaque match             
                                   
                                    $i = 0; 
                                    $index = [];
                                    $valeurs = [];
                                    foreach ($_POST as $key => $value) {
                                           $index[$i] = $key;
                                           $valeurs[$i] = $value;
                                           $i+=1;

                                    }
                                    $equipe1 = $index[1];
                                    $equipe2 = $index[2];

                                    $scoD5 = $valeurs[1];
                                    $scoD6 = $valeurs[2];
                                //permet de comparer les deux equipes
                                    for($i=0; $i<4; $i++){
                                           if($_SESSION['gA'][$i][0] == $equipe1){
                                                  $indice1 = $i;
                                                  echo($_SESSION['gA'][$indice1][0]);

                                    
                                           }                            
                                    }
                                    //permet de comparer les deux equipes
                                    for($i=0; $i<4; $i++){
                                           if($_SESSION['gA'][$i][0] == $equipe1){
                                                  $indice1 = $i;
                                                  echo($_SESSION['gA'][$indice1][0]);

                                           }                            
                                    }
                                   // permet de comparer les deux equipes
                                    for ($z=0; $z<4; $z++) { 
                                           if($_SESSION['gA'][$z][0] == $equipe2){
                                                  $indice2 = $z;
                                                  echo($_SESSION['gA'][$indice2][0]);
                                           }
                                    }
                
                     }    
                    
 
              ?>
       </div>
            
               <!-- celebration -->
       <div class="lk">
              <img src="cp.jpg"><br>
         <?php
               if(!empty($_SESSION['matches3'])){

                      if($_SESSION['matches3'][0] > $_SESSION['matches3'][1]){
                            
                     $_SESSION['eq1Enfinal'] = $eq1Enfinal;
                     echo $_SESSION['eq1Enfinal'];
                     }
                            
                    else if($_SESSION['matches3'][0]< $_SESSION['matches3'][1]){
                            
                       $_SESSION['eq1Enfinal'] = $eq2Enfinal;
                       echo  $_SESSION['eq2Enfinal'];           
                     }else{
                             $_SESSION['eq1Enfinal'] = $eq1Enfinal = "";
                     }
              }       
         ?> 
       </div>                                 
<!-- script pour verrouiller les boutons -->
       <script>
              // code javascript pour disable button6
              let boutonVal1 = document.querySelector('button.cacherButton');       
              boutonVal1.setAttribute('disabled',"");
       </script>
        <script>
              // code javascript pour disable button6
              let boutonVal2 = document.querySelector('button.cacherButton2');       
              boutonVal2.setAttribute('disabled',"");
       </script>
        <script>
              // code javascript pour disable button6
              let boutonVal3 = document.querySelector('button.cacherButton3');       
              boutonVal3.setAttribute('disabled',"");
       </script>
        <script>
              // code javascript pour disable button6
              let boutonVal4 = document.querySelector('button.cacherButton4');       
              boutonVal4.setAttribute('disabled',"");
       </script>
               


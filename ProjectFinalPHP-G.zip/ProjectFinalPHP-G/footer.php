<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css" />
    <title>Document</title>
</head>
<body>
    
<!-- <div class="footer">
<h3>Copyright@ 2021 Tous droit reserve</h3>
<div class="icone">
    <img src="./foto/call.png">
    <img src="./foto/facebook.png">
    <img src="./foto/you.png">
    <img src="./foto/wat.png">
</div>
</div>
<style>
    h3{
        position: relative;
        left: 75%;
        width: 23%;
        color: #fff; 
    }
    .icone{
        position: relative;
        left: 75%;
        width: 20%; 
    }
    .icone img:hover{
        animation-name:rotation; 
        animation-duration: 3s;
        cursor: pointer;
        }
        @keyframes rotation{
        0%{transform: rotate(20deg)};
        } -->
<!-- </style> -->


    <!-- sponsor -->
    <section class="section">
      <div class="brands-center container">
        <div class="brand">
          <img src="./foto/brand1.png" alt="" />
        </div>
        <div class="brand">
          <img src="./foto/brand2.png" alt="" />
        </div>
        <div class="brand">
          <img src="./foto/brand1.png" alt="" />
        </div>
        <div class="brand">
          <img src="./foto/brand2.png" alt="" />
        </div>
        <div class="brand">
          <img src="./foto/brand1.png" alt="" />
        </div>
      <!--   <div class="brand">
          <img src="./foto/brand2.png" alt="" />
        </div>
 -->      </div>
    </section>
  </main>
  <!-- Footer -->
  <footer id="footer" class="section footer">
    <div class="container">
      <div class="footer-container">
        <div class="footer-center">
          <h3>EXTRAS</h3>
          <a href="#">Brands</a>
          <a href="#">Certificat</a>
          <a href="#">Affiliation</a>
          <a href="#">Speciale</a>
          <a href="#">Guide</a>
        </div>
        <div class="footer-center">
          <h3>INFORMATION</h3>
          <a href="#">About Us</a>
          <a href="#">Privacy Policy</a>
          <a href="#">Terme et Conditions</a>
          <a href="#">Nous contacter</a>
          <a href="#">Guide</a>
        </div>
        <div class="footer-center">
          <h3>MON COMPTE</h3>
          <a href="#">Mon Compte</a>
          <a href="#">Historicite</a>
          <a href="#">la Liste</a>
          <a href="#">Boite au lettre</a>
          <a href="#">Retourner</a>
        </div>
        <div class="footer-center">
          <h3>NOUS CONTACTER</h3>
          <div>
            <span>
              <i class="fas fa-map-marker-alt"></i>
            </span>
               Tabarre 48,Boulevard 15 octobre
          </div>
          <div>
            <span>
              <i class="far fa-envelope"></i>
            </span>
            Github@gmail.com
          </div>
          <div>
            <span>
              <i class="fas fa-phone"></i>
            </span>
            tel:(509).........
          </div>
          <div>
            <span>
              <i class="far fa-paper-plane"></i>
            </span>
            Port-au-prince, HAITI
          </div>
        </div>
      </div>
    </div>
    </div>
  </footer>
  <!-- End Footer -->
    </body>
    </html>